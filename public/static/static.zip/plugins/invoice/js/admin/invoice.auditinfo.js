$(function()
{
    // 审核操作事件
    $('.audit-type-container input[name="type"]').on('change', function()
    {
        var value = parseInt($(this).val());
        var $reason_container = $('.audit-refuse-reason-container');
        if(value == 0)
        {
            // 拒绝必须填写拒绝原因
            $reason_container.show();
            $reason_container.find('textarea').attr('required', true);
        } else {
            $reason_container.hide();
            $reason_container.find('textarea').attr('required', false);
        }
    });
});