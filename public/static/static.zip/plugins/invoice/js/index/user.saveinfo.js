/**
 * 发票选择容器处理
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2020-12-02
 * @desc    description
 */
function InvoiceContainerHandle()
{
    // 元素块容器
    var $company_container = $('.company-container');
    var $company_special_container = $('.company-special-container');
    var $addressee_container = $('.addressee-container');
    var $email_container = $('.email-container');

    // 发票类型
    var invoice_type = parseInt($('select[name="invoice_type"]').val());
    if(invoice_type == 2 || invoice_type == 3)
    {
        // 选择专票的时候申请类型必须是企业
        $('select[name="apply_type"]').val(1);
        $('select[name="apply_type"] option[value="0"]').attr('disabled', true);
    } else {
        $('select[name="apply_type"] option[value="0"]').attr('disabled', false);
    }
    $('select[name="apply_type"]').trigger('chosen:updated');

    // 申请类型
    switch(invoice_type)
    {
        // 增值税普通电子发票
        case 0 :
            $company_special_container.hide();
            $addressee_container.hide();
            $email_container.show();
            break;

        // 增值税普通纸质发票
        case 1 :
            $company_special_container.hide();
            $addressee_container.show();
            $email_container.hide();
            break;

        // 增值税专用纸质发票
        case 2 :
            $company_special_container.show();
            $addressee_container.show();
            $email_container.hide();
            $company_container.show();
            break;

        // 增值税专用纸质发票
        case 3 :
            $company_special_container.show();
            $addressee_container.hide();
            $email_container.show();
            $company_container.show();
            break;
    }

    // 增值税专用纸质发票情况下个人类型处理
    if(invoice_type == 0 || invoice_type == 1)
    {
        var apply_type = parseInt($('select[name="apply_type"]').val());
        if(apply_type == 0)
        {
            $company_container.hide();
        } else {
            $company_container.show();
        }
    }
}

$(function()
{
    // 初始化显隐处理、可能发票类型有限制导致默认的显隐不匹配
    InvoiceContainerHandle();

    // 发票类型事件,申请类型事件
    // 发票类型（0增值税普通电子发票、1增值税普通纸质发票、2增值税专用纸质发票、3增值税专用电子发票）
    // 申请类型（0个人、1企业）
    $('select[name="invoice_type"],select[name="apply_type"]').on('change', function()
    {
        InvoiceContainerHandle();
    });
});