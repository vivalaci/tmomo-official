$(function()
{
    // 批量选择开票
    $('.batch-invoice-submit').on('click', function()
    {
        // 是否有选择的数据
        var values = FromTableCheckedValues('plugins_invoice_form_checkbox_value', '.am-table-scrollable-horizontal');
        if(values.length <= 0)
        {
            Prompt('请先选中数据');
            return false;
        }

        // url支付地址
        var url = $(this).data('url') || null;
        if(url == null)
        {
            Prompt('url地址有误');
            return false;
        }

        // 进入开票页面
        window.location.href = UrlFieldReplace('ids', values.join(','), url);
    });
});