function isshowendnum(){
	
}