// 用户搜索列表
var $search_select_container = $('.user-search-select-container');
var $user_search_list = $search_select_container.find('.search-user-list');
var $input = $('.user-input-search-container input');

/**
 * 快捷用户弹层搜索
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2022-11-09
 * @desc    description
 */
function UserInputSearchModalQuery()
{
    // 空关键字不搜索
    var keywords = $input.val() || null;
    if(keywords == null)
    {
        $user_search_list.addClass('am-hide');
        Prompt('请输入用户码/名/昵称/手机/邮箱');
        return false;
    }

    // 开始搜索
    $user_search_list.html('').addClass('am-hide');
    var $tips = $search_select_container.find('.search-tips');
    $tips.text(keywords+' '+($search_select_container.data('search-loading-tips') || '搜索中...')).removeClass('am-hide');
    $.ajax({
        url: $search_select_container.data('url'),
        type: 'post',
        data: {"page":1, "keywords":keywords},
        dataType: 'json',
        success:function(res)
        {
            if(res.code == 0)
            {
                // 隐藏提示
                $tips.addClass('am-hide');
                // 添加数据导列表
                var html = '';
                for(var i in res.data)
                {
                    html += `<li class="am-nbfc am-padding-sm">
                            <img src="`+res.data[i]['avatar']+`" width="20" height="20" class="am-fl am-circle" />
                            <p class="am-margin-left-xs am-fl">`+res.data[i]['user_name_view']+`</p>
                            <a href="javascript:;" class="am-badge am-badge-secondary am-radius am-fr choice-submit" data-id="`+res.data[i]['id']+`" data-avatar="`+res.data[i]['avatar']+`" data-username="`+res.data[i]['username']+`" data-nickname="`+res.data[i]['nickname']+`" data-mobile="`+res.data[i]['mobile']+`" data-email="`+res.data[i]['email']+`">`+($search_select_container.data('choice-submit-text') || '选择')+`</a>
                        </li>`;
                }
                html += '<p class="am-text-warning am-text-center am-padding-vertical-sm">展示'+res.data.length+'条用户数据</p>';
                $user_search_list.html(html).removeClass('am-hide');
                // 仅一个则默认选上
                if($user_search_list.find('li').length == 1)
                {
                    $user_search_list.find('li .choice-submit').trigger('click');
                    $search_select_container.addClass('am-hide');
                    $input.val('');
                }
            } else {
                $tips.text(keywords+' '+res.msg).removeClass('am-hide');
            }
        },
        error:function(res)
        {
            var msg = HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误');
            $tips.text(res.msg).removeClass('am-hide');
        }
    });
}

/**
 * 下拉搜索用户选择
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2022-11-09
 * @desc    description
 * @param   {[object]}        e [选择对象]
 */
function UserInputSearchSelectChoice(e)
{
    // 用户数据显示
    var not_data_tips = '<span class="am-text-grey">...</span>';
    var $user_info = $('.user-info');
    $user_info.find('.avatar').attr('src', e.data('avatar'));
    $user_info.find('.username').html(e.data('username') || not_data_tips);
    $user_info.find('.nickname').html(e.data('nickname') || not_data_tips);
    $user_info.find('.mobile').html(e.data('mobile') || not_data_tips);
    $user_info.find('.email').html(e.data('email') || not_data_tips);
    $user_info.find('input[name="user_id"]').val(e.data('id'));
    Prompt('用户选择成功', 'success');

    // 关闭弹窗
    $search_select_container.addClass('am-hide');
}

$(function()
{
    // 选择用户
    $('.user-info .user-choice-submit').on('click', function()
    {
        if($search_select_container.hasClass('am-hide'))
        {
            $search_select_container.removeClass('am-hide');
        } else {
            $search_select_container.addClass('am-hide');
        }
    });
    // 用户输入搜索 - 回车
    $('.user-input-search-container input').on('keydown', function()
    {
        if(event.keyCode == 13)
        {
            UserInputSearchModalQuery();
            return false;
        }
    });
    // 用户搜索
    $('.user-input-search-container button').on('click', function()
    {
        UserInputSearchModalQuery();
    });
    // 用户选择确认
    $(document).on('click', '.search-user-list .choice-submit', function()
    {
        UserInputSearchSelectChoice($(this));
    });
});