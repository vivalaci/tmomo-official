$(function()
{
    // 表单初始化
    FromInit('form.form-validation-take');

    // 取货操作
    $(document).on('click', '.submit-take', function()
    {
        var $modal = $('#order-take-modal');
        $modal.find('input[name="id"]').val($(this).data('id') || 0);
        $modal.find('input[name="user_id"]').val($(this).data('user-id') || 0);
        $modal.modal({
            closeViaDimmer: 0,
            width: 300,
            height: 200
        });
    });
});