$(function()
{
    // 表单初始化
    FromInit('form.form-validation-audit');

    // 审核拒绝操作
    $('.submit-fail').on('click', function()
    {
        var $modal = $('#order-audit-modal');
        $modal.find('input[name="id"]').val($(this).data('id'));
        $modal.modal({
            closeViaDimmer: 0,
            width: 200,
            height: 180
        });
    });
});