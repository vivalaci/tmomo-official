/**
 * 基础数据总数
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2021-08-30
 * @desc    description
 * @param   {[array]}        data      [数据]
 */
function TopBaseCount(data)
{
    // 新增客户
    var $base_user_content = $('ul.base-user-content');
    $base_user_content.find('.order-new-user-count').text(data.base_data.order_new_user_count);
    $base_user_content.find('.order-new-user-valid-count').text(data.base_data.order_new_user_valid_count);
    $base_user_content.find('.order-new-user-need-repurchase-count').text(data.base_data.order_new_user_need_repurchase_count);
    $base_user_content.find('.order-new-user-total-price').text(data.base_data.order_new_user_total_price);
    $base_user_content.find('.order-user-count').text(data.base_data.order_user_count);
    $base_user_content.find('.order-user-total-price').text(data.base_data.order_user_total_price);

    // 推广客户
    var $promotion_user_content = $('ul.promotion-user-content');
    $promotion_user_content.find('.user-count').text(data.user_promotion_data.user_count);
    $promotion_user_content.find('.valid-user-count').text(data.user_promotion_data.valid_user_count);
    $promotion_user_content.find('.not-consumed-user-count').text(data.user_promotion_data.not_consumed_user_count);
}

/**
 * 收益走势
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2021-08-30
 * @desc    description
 * @param   {[array]}        title_arr [标题]
 * @param   {[array]}        name_arr  [名称]
 * @param   {[array]}        data      [数据]
 */
function EchartsProfit(name_arr, data)
{
    var chart = echarts.init(document.getElementById('echarts-profit'), 'macarons');
    var option = {
        tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
        grid: {
            top: '13%',
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            show : (__is_mobile__ == 1) ? false : true,
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: false},
                saveAsImage : {name:'收益走势', show: true}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap : false,
            data: name_arr
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: data,
            type: 'line'
        }]
    };
    chart.setOption(option);
    return chart;
}

/**
 * 推广用户走势
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2021-08-30
 * @desc    description
 * @param   {[array]}        title_arr [标题]
 * @param   {[array]}        name_arr  [名称]
 * @param   {[array]}        data      [数据]
 */
function EchartsUser(name_arr, data)
{
    var chart = echarts.init(document.getElementById('echarts-user'), 'macarons');
    var option = {
        tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
        grid: {
            top: '13%',
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            show : (__is_mobile__ == 1) ? false : true,
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: false},
                saveAsImage : {name:'推广用户数', show: true}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap : false,
            data: name_arr
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: data,
            type: 'bar',
            areaStyle: {}
        }]
    };
    chart.setOption(option);
    return chart;
}

/**
 * 图表更新
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2021-08-30
 * @desc    description
 * @param   {[object]}        e [操作对象]
 */
var chart_object = [];
function EchartsInit(e)
{
    // 类型
    var type = e.parents('.right-operate').data('type');
    var value = e.parents('.echarts-title').find('select[name="value"]').val() || '';

    // 时间
    var $time = e.parent();
    var start = $time.find('input[name="time_start"]').val() || '';
    var end = $time.find('input[name="time_end"]').val() || '';
    var uid = $('.content-right').data('uid') || 0;

    // ajax
    e.button('loading');
    $.AMUI.progress.start();
    $.ajax({
        url: $('.content-right').data('url'),
        type: 'POST',
        dataType: 'json',
        timeout: 30000,
        data: {"type":type, "start":start, "end":end, "value": value, "uid": uid},
        success: function(res)
        {
            e.button('reset');
            $.AMUI.progress.done();
            if(res.code == 0)
            {
                var chart = null;
                switch(type)
                {
                    // 基础数据
                    case 'base' :
                        TopBaseCount(res.data);
                        break;

                    // 收益走势
                    case 'profit' :
                        var chart = EchartsProfit(res.data.name_arr, res.data.data);
                        break;

                    // 推广用户走势
                    case 'user' :
                        var chart = EchartsUser(res.data.name_arr, res.data.data);
                        break;

                    default :
                        console.info('操作类型未定义['+type+']')
                }

                // 图表对象存储
                if(chart !== null)
                {
                    chart_object.push(chart);
                }
            } else {
                Prompt(res.msg);
            }
        },
        error: function(xhr, type)
        {
            e.button('reset');
            $.AMUI.progress.done();
            Prompt(HtmlToString(xhr.responseText) || '异常错误', null, 30);
        }
    });
}

$(function()
{
    // 初始化
    $('.content-right .echarts-where-submit').each(function(k ,v)
    {
        if(parseInt($(this).parents('.right-operate').data('init')) == 1)
        {
            EchartsInit($(this));
        }
    });

    // 基础条件值改变事件
    $('.echarts-title select[name="value"]').on('change', function()
    {
        $(this).parent().find('button.echarts-where-submit').trigger('click');
    });

    // 条件确认
    $('.echarts-where-submit').on('click', function()
    {
        EchartsInit($(this));
    });

    // 快捷时间
    $('.quick-time a').on('click', function()
    {
        // 参数判断
        var start = $(this).data('start') || '';
        var end = $(this).data('end') || '';
        var is_empty_time = parseInt($(this).parents('.right-operate').data('empty-time')) || 0;
        if(is_empty_time == 0 && (start == '' || end == ''))
        {
            Prompt('快捷时间配置有误');
            return false;
        }

        // 时间
        var $time = $(this).parent().next();
        if(!$time.find('button').is(':disabled'))
        {
            $time.find('input[name="time_start"]').val(start);
            $time.find('input[name="time_end"]').val(end);
            $time.find('button.echarts-where-submit').trigger('click');
        }
    });

    // 浏览器大小改变则实时更新图表大小
    window.onresize = function()
    {
        if(chart_object.length > 0)
        {
            for(var i in chart_object)
            {
                chart_object[i].resize();
            }
        }
    };
});