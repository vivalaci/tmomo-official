$(function()
{
     // 商品标题
    $('input[name="goods_title_text_color"]').on('change', function()
    {
        $('.goods-title').css('color', $(this).val());
    });

    // 商品简述
    $('input[name="goods_simple_text_color"]').on('change', function()
    {
        $('.goods-simple-desc').css('color', $(this).val());
    });

    // 价格信息文本改变
    $('input[name="price_custom_text"]').on('change', function()
    {
        var text = $(this).val() || null;
        if(text == null)
        {
            $('.price-text').html('<span>销售价：<span class="am-text-danger">￥0.00</span></span><br /><span class="am-text-grey">原价：0.00</span>');
            $('.price-text').css('color', '');
        } else {
            $('.price-text').text(text);
        }
    });
    // 价格信息颜色
    $('input[name="price_custom_text_color"]').on('change', function()
    {
        $('.price-text').css('color', $(this).val());
    });

    // 底部左侧文本改变
    $('input[name="bottom_left_text"]').on('change', function()
    {
        $('.bottom-left').text($(this).val());
    });
    // 底部左侧文本颜色
    $('input[name="bottom_left_text_color"]').on('change', function()
    {
        $('.bottom-left').css('color', $(this).val());
    });

    // 底部右侧文本改变
    $('input[name="bottom_right_text"]').on('change', function()
    {
        $('.bottom-right').text($(this).val());
    });
    // 底部右侧文本颜色
    $('input[name="bottom_right_text_color"]').on('change', function()
    {
        $('.bottom-right').css('color', $(this).val());
    });
});