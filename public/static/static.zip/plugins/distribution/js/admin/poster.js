$(function()
{
    // 没有加载表单不初始化js
    if($('.poster-right').length > 0)
    {
        // 样式列表
        var border_style_all = $('.poster-right').data('border-style');

        // 初始化
        function PosterAvatarInit()
        {
            $('input[name="avatar_top"]').val($('.avatar').position().top);
            $('input[name="avatar_left"]').val($('.avatar').position().left);
        }
        function PosterUserInit()
        {
            $('input[name="userinfo_top"]').val($('.userinfo').position().top);
            $('input[name="userinfo_left"]').val($('.userinfo').position().left);
        }
        function PosterQrcodeInit()
        {
            $('input[name="qrcode_top"]').val($('.qrcode').position().top);
            $('input[name="qrcode_left"]').val($('.qrcode').position().left);
        }

        // 拖动初始化
        $('.avatar').Tdrag({
             scope:".poster-images",
             cbEnd:function()
             {
                PosterAvatarInit();
             }
        });
        $('.userinfo').Tdrag({
             scope:".poster-images",
             cbEnd:function()
             {
                PosterUserInit();
             }
        });
        $('.qrcode').Tdrag({
             scope:".poster-images",
             cbEnd:function()
             {
                PosterQrcodeInit();
             }
        });

        // 用户信息-颜色事件
        $('input[name="userinfo_color"]').on('change', function()
        {
            $('.userinfo').css('color', $(this).val());
        });

        // 用户信息-字体大小事件
        $('input[name="userinfo_size"]').on('keyup', function()
        {
            var val = $(this).val() || 14;
            $('.userinfo').css({"font-size": val+'px'});
        });

        // 头像事件
        $('input[name="avatar_width"]').on('keyup', function()
        {
            var val = $(this).val() || 0;
            if(val >= parseInt($(this).attr('min')) && val <= parseInt($(this).attr('max')))
            {
                var left = ((300-val)/2)-1;
                $('.avatar').css({"width": val+'px', "left": ((left <= 0) ? 0 : left)+'px'});
                PosterAvatarInit();
            }
        });

        // 头像样式
        $('input[name="avatar_border_style"]').on('change', function()
        {
            var val = $(this).val() || 0;
            for(var i in border_style_all)
            {
                if(i > 0)
                {
                    if(val == i)
                    {
                        $('.avatar').addClass(border_style_all[val]);
                    } else {
                        $('.avatar').removeClass(border_style_all[i]);
                    }
                }
            }
        });

        // 二维码事件
        $('input[name="qrcode_width"]').on('keyup', function()
        {
            var val = $(this).val() || 0;
            if(val >= parseInt($(this).attr('min')) && val <= parseInt($(this).attr('max')))
            {
                var left = ((300-val)/2)-1;
                $('.qrcode').css({"width": val+'px', "left": ((left <= 0) ? 0 : left)+'px'});
                PosterQrcodeInit();
            }
        });

        // 头像样式
        $('input[name="qrcode_border_style"]').on('change', function()
        {
            var val = $(this).val() || 0;
            for(var i in border_style_all)
            {
                if(i > 0)
                {
                    if(val == i)
                    {
                        $('.qrcode').addClass(border_style_all[val]);
                    } else {
                        $('.qrcode').removeClass(border_style_all[i]);
                    }
                }
            }
        });
    }

    // 海报恢复默认
    $('.poster-recovery-default').on('click', function()
    {
        var default_poster = $(this).data('default-poster');
        $('input[name="backdrop"]').val(default_poster);
        $('.backdrop').attr('src', default_poster);
        Prompt('恢复成功', 'success');
    });
});