// 添加元素到右侧
function RightElementAdd(obj, spec_data = '', spec_value = '')
{
    var goods_url = obj.attr('data-goods-url');
    var value = obj.attr('data-value');
    var price = obj.attr('data-price');
    var images = obj.attr('data-images');
    var inventory = obj.attr('data-inventory');
    var inventory_unit = obj.attr('data-inventory-unit');
    var name = obj.find('.name').text();
    if($('.forth-selection-container ul.ul-right').find('.items-li-'+value+spec_value).length == 0)
    {
        spec_data = (spec_data || null) == null ? '' : encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(spec_data))));
        var html = `<li class="am-animation-slide-bottom items-li-`+value+spec_value+`" data-value="`+value+`" data-spec="`+spec_data+`">
                        <img src="`+images+`" class="am-radius" />
                        <p class="name am-text-truncate"><a href="`+goods_url+`" target="_blank" title="`+spec_value+name+`">`+spec_value+name+`</a></p>
                        <p class="price-inventory am-text-truncate am-fr">
                            <strong class="am-text-danger">`+__currency_symbol__+price+`</strong>
                            <span class="am-fr">`+inventory+inventory_unit+`</span>
                        </p>
                        <i class="iconfont icon-delete am-fr"></i>
                    </li>`;
        $('.forth-selection-container ul.ul-right').append(html);
    }

    // 右侧数据同步
    RightElementGoods();

    // 左侧是否还有内容
    if($('.forth-selection-container ul.ul-left li').length == 0)
    {
        $('.forth-selection-container ul.ul-left .data-list-bottom-tips').remove();
        $('.forth-selection-container ul.ul-left .table-no').removeClass('none');
    } else {
        $('.forth-selection-container ul.ul-left .table-no').addClass('none');
    }

    // 移除左侧的内容
    obj.remove();

    // 标签title属性初始化
    ViewDocumentTitleInit();
}

// 批量-商品id同步
function RightElementGoods()
{
    // 循环获取已选择的商品
    var goods = [];
    $('.forth-selection-container ul.ul-right li').each(function(k, v)
    {
        var spec = $(this).data('spec') || '';
        if(spec != '')
        {
            spec = CryptoJS.enc.Base64.parse(decodeURIComponent(spec)).toString(CryptoJS.enc.Utf8);
        }
        goods.push({goods_id: $(this).data('value'), spec: spec});
    });
    $('.forth-selection-container input[name="goods_data"]').val((goods.length > 0) ? encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(goods)))) : '').blur();

    // 右侧是否还有数据
    var $table_no = $('.forth-selection-container ul.ul-right .table-no');
    if($('.forth-selection-container ul.ul-right li').length == 0)
    {
        $table_no.removeClass('none');
    } else {
        $table_no.addClass('none');
    }
}

// 商品规格选择回调处理 - 获取规格详情数据
function GoodsChoiceBackHandleSpecDetail(data)
{
    $.AMUI.progress.start();
    $.ajax({
        url: RequestUrlHandle(__goods_spec_detail_url__),
        type: 'post',
        dataType: 'json',
        timeout: 10000,
        data: {"id": data.obj.parent().data('value'), "spec": data.spec, "stock": 1},
        success: function(res)
        {
            $.AMUI.progress.done();
            if(res.code == 0)
            {
                data.obj.parent().attr('data-price', res.data.spec_base.price);
                data.obj.parent().attr('data-inventory', res.data.spec_base.inventory);
                RightElementAdd(data.obj.parent(), data.spec, '（'+data.value.join('')+'）');
            } else {
                Prompt(res.msg);
            }
        },
        error: function(xhr, type)
        {
            $.AMUI.progress.done();
            Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
        }
    });
}

$(function()
{
    // 左侧点击到右侧
    $('.forth-selection-container ul.ul-left').on('click', 'i.icon-angle-right', function()
    {
        // 是否多规格
        if($(this).data('is-spec') != 1)
        {
            RightElementAdd($(this).parent());
        }
    });

    // 右侧删除
    $('.forth-selection-container ul.ul-right').on('click', 'i.icon-delete', function()
    {
        $(this).parent().remove();
        RightElementGoods();
    });

    // 商品搜索
    $('.forth-selection-form .search-submit').on('click', function()
    {
        var category_id = $('.forth-selection-form .forth-selection-form-category').val() || '';
        var keywords = $('.forth-selection-form .forth-selection-form-keywords').val() || '';

        var $btn = $(this);
        $btn.button('loading');
        $.ajax({
            url:$('.forth-selection-form').data('search-url'),
            type:'POST',
            dataType:"json",
            timeout:10000,
            data:{"category_id": category_id, "keywords": keywords},
            success:function(result)
            {
                $btn.button('reset');
                if(result.code == 0)
                {
                    var html = '';
                    $('ul.ul-left li').remove();
                    $('ul.ul-left .data-list-bottom-tips').remove();
                    if(result.data.length > 0)
                    {
                        for(var i in result.data)
                        {
                            var spec_data = (result['data'][i]['is_exist_many_spec'] == 1 && (result['data'][i]['specifications'] || null) != null && (result['data'][i]['specifications']['choose'] || null) != null) ? encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(result['data'][i]['specifications']['choose'])))) : '';
                            html += `<li class="am-animation-slide-bottom" data-goods-url="`+result['data'][i]['goods_url']+`" data-value="`+result['data'][i]['id']+`" data-price="`+result['data'][i]['price']+`" data-images="`+result['data'][i]['images']+`" data-inventory="`+result['data'][i]['inventory']+`" data-inventory-unit="`+result['data'][i]['inventory_unit']+`">
                                        <img src="`+result['data'][i]['images']+`" class="am-radius" />
                                        <p class="name am-text-truncate"><a href="`+result['data'][i]['goods_url']+`" target="_blank" title="`+result['data'][i]['title']+`">`+result['data'][i]['title']+`</a></p>
                                        <p class="price-inventory am-text-truncate am-fr">
                                            <strong class="am-text-danger">`+__currency_symbol__+result['data'][i]['price']+`</strong>
                                            <span class="am-fr">`+result['data'][i]['inventory']+result['data'][i]['inventory_unit']+`</span>
                                        </p>
                                        <i class="iconfont icon-angle-right am-fr `+(result['data'][i]['is_exist_many_spec'] == 1 ? 'common-goods-spec-choice-submit-event' : '')+`" data-goods-id="`+result['data'][i]['id']+`" data-is-spec="`+result['data'][i]['is_exist_many_spec']+`" data-spec="`+spec_data+`" data-is-text-value="0" data-back-method="GoodsChoiceBackHandle"></i>
                                    </li>`;
                        }
                        html += '<p class="data-list-bottom-tips am-text-center am-text-warning am-padding-vertical-sm">'+($('.forth-selection-container').data('original-list-bottom-tips').replace('{val}', result.data.length))+'</p>'
                        $('ul.ul-left').append(html);
                        $('ul.ul-left .table-no').addClass('none');

                        // 标签title属性初始化
                        ViewDocumentTitleInit();
                    } else {
                        $('ul.ul-left .table-no').removeClass('none');
                    }
                } else {
                    Prompt(result.msg);
                }
            },
            error:function(xhr, type)
            {
                $btn.button('reset');
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    });

    // 回车搜索
    $('.forth-selection-form .forth-selection-form-keywords').on('keydown', function(event)
    {
        if(event.keyCode == 13)
        {
            $('.forth-selection-form .search-submit').trigger('click');
            return false;
        }
    });

    // 初始化搜索
    $('.forth-selection-form .search-submit').trigger('click');
});