$(function()
{
    // 用户搜索 - 确认
    $(document).on('click', '.plugins-distribution-search-user button', function()
    {
        var $search_user = $('.plugins-distribution-search-user');
        var $user_data = $search_user.find('.user-data');
        var $error_tips = $search_user.find('.error-tips');
        var keywords = $search_user.find('input').val() || null;
        var form_name = $search_user.data('form-name');
        var $input_form = $('input[name="'+form_name+'"]');
        if(keywords == null)
        {
            Prompt('请输入关键字搜索');
            return false;
        }

        // 查询用户
        var $this = $(this);
        $this.button('loading');
        $.ajax({
            url: $search_user.data('url'),
            type: 'POST',
            dataType: 'json',
            timeout: 30000,
            data: {keywords: keywords},
            success: function(res)
            {
                $this.button('reset');
                if(res.code == 0)
                {
                    $input_form.val(res.data.id);
                    $user_data.find('img').attr('src', res.data.avatar);
                    $user_data.find('.user-name-view').text(res.data.user_name_view);
                    $user_data.find('.user-add-time').text(res.data.add_time_text || '');
                    $user_data.removeClass('am-hide');
                    $error_tips.addClass('am-hide');
                } else {
                    $user_data.addClass('am-hide');
                    $error_tips.removeClass('am-hide').text(res.msg);
                    $input_form.val('');
                }
            },
            error: function(xhr, type)
            {
                $this.button('reset');
                Prompt(HtmlToString(xhr.responseText) || '异常错误', null, 30);
            }
        });
    });
    // 用户搜索 - 回车搜索
    $('.plugins-distribution-search-user input').on('keydown', function(event)
    {
        if(event.keyCode == 13)
        {
            $('.plugins-distribution-search-user button').trigger('click');
            return false;
        }
    });
});