// 数量更新
function PluginsDistributionNumberUpdate(parent, input, stock)
{
    var $item = parent.parents('li');
    var spec = $item.find('.checkbox-choice').data('spec') || '';
    if(spec != '')
    {
        spec = CryptoJS.enc.Base64.parse(decodeURIComponent(spec)).toString(CryptoJS.enc.Utf8);
    }
    $.AMUI.progress.start();
    $.ajax({
        url: RequestUrlHandle(__goods_stock_url__),
        type: 'post',
        dataType: "json",
        timeout: 10000,
        data: {
            "id": $item.data('goods-id'),
            "stock": stock,
            "spec": spec
        },
        success: function(res)
        {
            $.AMUI.progress.done();
            if(res.code == 0)
            {
                parent.find('input').val(stock);
                $item.find('.price').text(__currency_symbol__+res.data.spec_base.price);
                $item.find('.price').attr('data-price', res.data.spec_base.price);
                $item.find('.original-price').text(__currency_symbol__+res.data.spec_base.original_price);

                // 计算选择的商品总数和总价
                PluginsDistributionBaseTotal();
            } else {
                Prompt(res.msg);
            }
        },
        error: function(xhr, type)
        {
            $.AMUI.progress.done();
            Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
        }
    });
}

// 导航总价计算
function PluginsDistributionBaseTotal()
{
    // 已选商品
    var total_price = 0;
    $('.plugins-distribution-home-data-detail ul li').each(function()
    {
        if($(this).find('.checkbox-choice input').is(':checked'))
        {
            var stock = parseInt($(this).find('.stock-tag input[type="number"]').val() || 1);
            total_price += stock*parseFloat($(this).find('.price').attr('data-price') || 0);
        }
    });

    // 购买价格
    var $nav_price = $('.plugins-distribution-home-data-detail .nav .nav-right .nav-total-price');
    $nav_price.find('.price').text(__currency_symbol__+FomatFloat(total_price));
}

$(function()
{
    // 导航固定
    var $detail = $('.plugins-distribution-home-data-detail');
    var $nav = $detail.find('.nav');
    var nav_top = $nav.length > 0 ? $nav.offset().top : 0;
    function BuyNavPop()
    {
        var scroll = $(document).scrollTop();
        var height = $nav.innerHeight();
        var location = scroll+$(window).height()-height;
        if(location < nav_top)
        {
            $nav.css({"position":"fixed", "bottom":0, "width":$detail.width()+"px", "z-index":1000}).addClass('am-box-shadow-top am-radius-bottom-left-0 am-radius-bottom-right-0');
            $('body').css({"padding-bottom":height+"px"});
        } else {
            $nav.css({"position":"relative", "bottom":0, "z-index":0, "width":"100%"}).removeClass('am-box-shadow-top am-radius-bottom-left-0 am-radius-bottom-right-0');
            $('body').css({"padding-bottom":"0"});
        }
    }
    BuyNavPop();
    $(window).scroll(function()
    {
        BuyNavPop();
    });
    // 浏览器窗口实时事件
    $(window).resize(function()
    {
        BuyNavPop();
    });

    // 输入事件
    $('.stock-tag input[type="number"]').on('blur', function()
    {
        // 数量参数
        var $input = $(this);
        var $parent = $input.parents('.stock-tag');
        var inventory = parseInt($parent.data('inventory'));
        var min = parseInt($input.data('min-limit') || 1);
        var max = parseInt($input.data('max-limit'));
        var stock = parseInt($input.val());
        if(isNaN(stock))
        {
            stock = min;
        }
        if(max > 0 && stock > max)
        {
            stock = max;
        }
        if(stock < min)
        {
            stock = min;
        }
        if(stock > inventory)
        {
            stock = inventory;
        }
        $(this).val(stock);
        PluginsDistributionNumberUpdate($parent, $input, stock);
    });

    // 数量操作
    $('.stock-tag .stock-submit').on('click', function()
    {
        // 数量参数
        var $parent = $(this).parents('.stock-tag');
        var $input = $parent.find('input[type="number"]');
        var inventory = parseInt($parent.data('inventory'));
        var min = parseInt($input.data('min-limit') || 1);
        var max = parseInt($input.data('max-limit'));
        var unit = $input.data('unit') || '';
        var stock = parseInt($input.val());
        var type = $(this).data('type');
        if(type == 'add')
        {
            var temp_stock = stock+1;
            if(max > 0 && temp_stock > max)
            {
                $input.val(max);
                Prompt((window['lang_goods_stock_max_tips'] || '最大限购数量')+max+unit);
                return false;
            }
            // 超过库存
            if(temp_stock > inventory)
            {
                temp_stock = inventory;
                Prompt((window['lang_goods_inventory_number_tips'] || '库存数量')+inventory+unit);
                return false;
            }
        } else {
            var temp_stock = stock-1;
            if(temp_stock < min)
            {
                $input.val(min);
                Prompt((window['lang_goods_stock_min_tips'] || '最低起购数量')+min+unit);
                return false;
            }
            // 超过库存
            if(temp_stock > inventory)
            {
                temp_stock = inventory;
            }
        }

        PluginsDistributionNumberUpdate($parent, $input, temp_stock);
    });

    // 选择计算
    $('.plugins-distribution-home-data-detail ul li input[type="checkbox"]').on('change', function()
    {
        // 计算选择的商品总数和总价
        PluginsDistributionBaseTotal();
    });

    // 立即购买
    $('.plugins-distribution-home-data-detail .buy-submit').on('click', function()
    {
        if(__user_id__ != 0)
        {
            // 是否需要选择商品
            var goods_data = [];
            $('.plugins-distribution-home-data-detail ul li').each(function(k, v)
            {
                if(!$(this).find('.item-content').hasClass('item-error') && $(this).find('input[type="checkbox"]:checked').length > 0)
                {
                    var spec = $(this).find('.checkbox-choice').data('spec') || '';
                    if(spec != '')
                    {
                        spec = CryptoJS.enc.Base64.parse(decodeURIComponent(spec)).toString(CryptoJS.enc.Utf8);
                    }
                    goods_data.push({
                        goods_id: $(this).data('goods-id'),
                        stock: parseInt($(this).find('.stock-tag input[type="number"]').val() || 1),
                        spec: spec
                    });
                }
            });
            var buy_min_number = 1;
            if(goods_data.length < buy_min_number)
            {
                Prompt('请至少选择'+buy_min_number+'个商品');
                return false;
            }

            // 进入购买表单
            var $form = $('form.buy-form');
            $form.find('input[name="goods_data"]').val(encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(goods_data)))));
            $form.find('button[type="submit"]').trigger('click');
        }
    });
});