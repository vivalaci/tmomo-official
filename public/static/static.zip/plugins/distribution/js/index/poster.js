$(function()
{
    // url复制
    var clipboard = new ClipboardJS('.user-content-body .poster-right .am-input-group .am-input-group-btn',
    {
        text: function()
        {
            return $('.user-content-body .poster-right .am-input-group input').val();
        }
    });
    clipboard.on('success', function(e)
    {
        Prompt('复制成功', 'success');
    });
    clipboard.on('error', function(e)
    {
        Prompt('复制失败，请手动复制！');
    });

    // 点击选中input值
    $('.user-content-body .poster-right .am-input-group input').on('click', function()
    {
        $(this).select();
    });
});