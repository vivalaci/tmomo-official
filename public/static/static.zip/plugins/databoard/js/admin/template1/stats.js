// 定时任务临时变量
var order_day_timer = null;
var national_hot_timer = null;
var order_sales_timer = null;

// 定义初始的下标
var order_day_now_index = 0;
var national_hot_now_index = 0;
var order_sales_now_index = 0;

/**
 * 数据统计处理
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2022-01-27
 * @desc    description
 */
function stats()
{
    $.ajax({
        url: $('body').data('url'),
        type: 'POST',
        data_type: "json",
        timeout: 10000,
        data: {},
        success: function(res) {
            // 关闭弹层
            $('.loading-dimmer').hide();

            if (res.code == 0) {
                // 清除任务
                clearInterval(order_day_timer);
                clearInterval(national_hot_timer);
                clearInterval(order_sales_timer);

                // 概述
                var overview_arr = [{
                    title: "用户总量",
                    count: res.data.overview.user_count,
                    icon_color: "#006cff"
                }, {
                    title: "订单总量",
                    count: res.data.overview.order_count,
                    icon_color: "#9c27b0"
                }, {
                    title: "成交总量",
                    count: res.data.overview.order_done_count,
                    icon_color: "#6acca3"
                }, {
                    title: "收入总计(万)",
                    count: res.data.overview.order_income_price,
                    icon_color: "#e91e63"
                }];
                $('.overview .inner').empty();
                overview_arr.forEach((obj, index) => {
                    var the_div = `<div class="item">
                              <h4>${obj.count}</h4>
                              <span>
                                  <i class="icon-dot" style="color: ${obj.icon_color}"></i>
                                  ${obj.title}
                              </span>
                          </div>`;
                    $('.overview .inner').append(the_div);
                });





                // 订单、用户列表
                var monitor_arr = [{
                    title: "最新订单",
                    sub_title: [
                        "时间",
                        "金额",
                        "状态"
                    ],
                    content_arr: res.data.order_user_list.order_list
                }, {
                    title: "最新用户",
                    sub_title: [
                        "时间",
                        "昵称",
                        "性别"
                    ],
                    content_arr: res.data.order_user_list.user_list
                }];
                $('.monitor .tabs').empty();
                monitor_arr.forEach((obj, index) => {
                    // 1.tab栏的渲染  
                    var the_a = `<a href="javascript:;" data-index="${index}"
                             class="${index === 0 ? 'active' : ''}">
                           ${obj.title}
                          </a>`;
                    $('.monitor .tabs').append(the_a);
                    // 2.head区域的渲染  
                    // 默认展示的是数组中的第一项的数据
                    if (index === 0) {
                        render(obj)
                    }
                });
                /*
                  tab 注册点击事件
                  1.添加高亮
                  2.head区域重新渲染
                  3.滚动区域重新渲染
                */
                $(document).on('click', '.monitor .tabs a', function() {
                    $(this).addClass('active').siblings().removeClass('active')
                    // 获取下标
                    var index = $(this).index()
                    var obj = monitor_arr[index]
                    render(obj);
                });
                // 渲染方法
                function render(obj) {
                    // 先清空,再渲染
                    $('.monitor .head').empty();
                    $('.monitor .marquee').empty();
                    obj.sub_title.forEach(str => {
                        var the_span = `<span class="col">${str}</span>`
                        $('.monitor .head').append(the_span);
                    })

                    // 滚动区域的渲染
                    $('.monitor .marquee').empty();
                    obj.content_arr.forEach(content_div => {
                        var the_div = `<div class="row">
                                    <span class="col">${content_div.item1}</span>
                                    <span class="col">${content_div.item2}</span>
                                    <span class="col">${content_div.item3}</span>
                                    <span class="icon-dot"></span>
                                </div>`
                        $('.monitor .marquee').append(the_div);
                    });
                    // 一定要等到循环结束之后在克隆 
                    var clone_div = $('.monitor .marquee div').clone()
                        // 将克隆好的div添加到容器中 === marquee
                    $('.monitor .marquee').append(clone_div);
                }



                // 热销商品
                var chart_goods_hot = echarts.init(document.querySelector('.pie'), 'macarons');
                var chart_goods_hot_option = {
                    color: ['#006cff', '#60cda0', '#ed8884', '#ff9f7f', '#0096ff', '#9fe6b8', '#32c5e9', '#1d9dff'],
                    tooltip: {
                        trigger: 'item'
                    },
                    series: [{
                        name: '销量',
                        type: 'pie',
                        radius: ["10%", "70%"],
                        center: ['50%', '50%'],
                        roseType: 'radius',
                        itemStyle: {
                            borderRadius: 3
                        },
                        data: res.data.goods_hot.goods
                    }]
                };
                chart_goods_hot.setOption(chart_goods_hot_option);
                // 总数
                $('.goods-hot .data .item').eq(0).find('h4').text(res.data.goods_hot.goods_count);
                $('.goods-hot .data .item').eq(1).find('h4').text(res.data.goods_hot.sales_count);
                // 做监听,不会覆盖之前的window.onresize 的方法
                window.addEventListener('resize', function() {
                    chart_goods_hot.resize();
                });




                // 按月订单总量
                var chart_order_month_total_number = echarts.init(document.querySelector('.order-type .bar'), 'macarons');
                var chart_order_month_total_number_option = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    grid: {
                        top: '1%',
                        left: '0%',
                        right: '3%',
                        bottom: '0%',
                        containLabel: true
                    },
                    toolbox: {
                        show: false,
                        feature: {
                            mark: {
                                show: true
                            },
                            dataView: {
                                show: true,
                                readOnly: false
                            },
                            magicType: {
                                show: true,
                                type: ['line', 'bar']
                            },
                            restore: {
                                show: false
                            },
                            saveAsImage: {
                                name: '支付方式',
                                show: true
                            }
                        }
                    },
                    calculable: true,
                    xAxis: [{
                        axisLine: {
                            lineStyle: {
                                color: "#4186dc"
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: ['#094e62'],
                                width: 1,
                                type: 'solid'
                            }
                        },
                        type: 'category',
                        boundaryGap: false,
                        data: res.data.order_month_total_number.name_arr
                    }],
                    yAxis: [{
                        type: 'value',
                        axisLine: {
                            lineStyle: {
                                color: "#4b98f9"
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: ['#094e62'],
                                width: 1,
                                type: 'solid'
                            }
                        }
                    }, ],
                    series: res.data.order_month_total_number.data
                };
                chart_order_month_total_number.setOption(chart_order_month_total_number_option);
                // 总数
                $('.order-type .data .item').eq(0).find('h4').text(res.data.order_month_total_number.order_count);
                $('.order-type .data .item').eq(1).find('h4').text(res.data.order_month_total_number.user_count);
                // 做监听,不会覆盖之前的window.onresize 的方法
                window.addEventListener('resize', function() {
                    chart_order_month_total_number.resize()
                });





                /*
                  1.给当前a标签注册点击事件
                  2.添加高亮
                  3.获取自定义属性 day365
                  4.通过自定义属性,取出对应的数据
                  5.给页面去赋值
                */
                // 订单量设置内容
                $('.order h4').eq(0).text(res.data.order_day_total_number.day365.count)
                    // 销售额设置内容
                $('.order h4').eq(1).text(res.data.order_day_total_number.day365.total_price)
                $(document).on('click', '.order a', function() {
                    // 同步下标
                    order_day_now_index = $(this).index();
                    // 清除定时器
                    clearInterval(order_day_timer);
                    // 添加高亮
                    $(this).addClass('active').siblings().removeClass('active')
                        // 获取自定义属性
                    var data_key = $(this).attr('data-key');
                        // .语法不可以解析变量  []语法是可以解析变量
                    var data_obj = res.data.order_day_total_number[data_key]; // data.day365
                        // 订单量设置内容
                    $('.order h4').eq(0).text(data_obj.count);
                        // 销售额设置内容
                    $('.order h4').eq(1).text(data_obj.total_price);
                    // 在将定时器恢复回来
                    order_day_interval();
                });
                // 自动切换
                function order_day_interval(time) {
                    order_day_timer = setInterval(() => {
                        order_day_now_index++
                        // 由于当前的下标最大是3,所有需要加一个判断
                        if (order_day_now_index === $('.order a').length) {
                            order_day_now_index = 0
                        }
                        // 利用标签的主动触发事件
                        // 找到当前对应的a标签
                        $('.order a').eq(order_day_now_index).trigger('click');
                    }, 3000);
                }
                order_day_interval();




                // 订单销售额统计
                
                var order_sales_total_price_chart = echarts.init(document.querySelector('.sales .line'), 'macarons')
                var order_sales_total_price_option = {
                    color: ["#00f2f1", "#ed3f35"],
                    tooltip: {
                        trigger: 'axis'
                    },
                    grid: {
                        left: '0%',
                        right: '4%',
                        bottom: '0%',
                        top: '5%',
                        containLabel: true,
                        show: true,
                        borderColor: '#012f4a'
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        axisTick: { // 去掉刻度
                            show: false
                        },
                        axisLabel: { // 文字颜色
                            color: "#4c9bfd"
                        },
                        axisLine: { // xAxis轴-垂直线段
                            lineStyle: {
                                color: "#012f4a"
                            }
                        },
                        data: res.data.order_sales_total_price.year.name_arr,
                    },
                    yAxis: {
                        type: 'value',
                        axisLabel: { // 文字颜色
                            color: '#4c9bfd'
                        },
                        axisLine: { // y轴-垂直线段
                            lineStyle: {
                                color: "#012f4a"
                            }
                        },
                        splitLine: { //  轴线相关设置  
                            lineStyle: {
                                color: '#012f4a' // 坐标轴线(分割线)的颜色 
                            }
                        }
                    },
                    series: res.data.order_sales_total_price.year.data
                };
                order_sales_total_price_chart.setOption(order_sales_total_price_option)
                /*
                  1.给a标签注册点击事件
                  2.添加高亮
                  3.数据的切换
                */
                $(document).on('click', '.sales .caption a', function() {
                    // 同步下标
                    // 之所以减一,是因为a标签的下标从1开始,因为前面有一个h3标签
                    order_sales_now_index = $(this).index() - 1; // 兄弟节点中的位置 下标
                        // 添加高亮
                    $(this).addClass('active').siblings().removeClass('active');
                        // 获取自定义属性
                    var data_type = $(this).attr('data-type');
                        // 通过自定义属性获取对象里面对应的数据
                    order_sales_total_price_option.xAxis.data = res.data.order_sales_total_price[data_type].name_arr;
                    order_sales_total_price_option.series = res.data.order_sales_total_price[data_type].data;
                    // 将修改后的option重新的去设置
                    order_sales_total_price_chart.setOption(order_sales_total_price_option);
                });
                // 绑定鼠标移入移出事件
                $('.sales').hover(function() {
                    // 清除定时器
                    clearInterval(order_sales_timer);
                }, function() {
                    // 恢复定时器
                    order_sales_interval();
                });

                // 自动切换
                function order_sales_interval() {
                    clearInterval(order_sales_timer);
                    order_sales_timer = setInterval(() => {
                        order_sales_now_index++
                        if (order_sales_now_index === $('.sales .caption a').length) {
                            order_sales_now_index = 0
                        }
                        $('.sales .caption a').eq(order_sales_now_index).trigger('click');
                    }, 3000);
                }
                order_sales_interval();
                // 做监听,不会覆盖之前的window.onresize 的方法
                window.addEventListener('resize', function() {
                    order_sales_total_price_chart.resize();
                });




                // 支付方式分布
                if (res.data.payment_scatter.length > 0) {
                    $('.channel .data').empty();
                    $('.channel .data').addClass('data-' + res.data.payment_scatter.length);
                    res.data.payment_scatter.forEach(content_div => {
                        var the_div = `<div class="item">
                              <h4>${content_div.rate} <small>%</small></h4>
                              <p>${content_div.name}</p>
                            </div>`;
                        $('.channel .data').append(the_div);
                    });
                } else {
                    $('.channel .data').html('<div class="tips">无支付数据</div>');
                }




                // 一季度销售进度
                // 环状半圆形饼图
                var already_speed = (res.data.month_sales_speed.speed / 100) * 200;
                if(already_speed > 200) {
                    already_speed = 200;
                }
                var not_speed = 200 - already_speed;
                var month_sales_speed_chart = echarts.init(document.querySelector('.gauge'), 'macarons');
                var month_sales_speed_option = {
                    grid: {
                        left: "3%",
                        right: "3%",
                        bottom: "3%",
                        containLabel: true
                    },
                    series: [{
                        name: "一般",
                        type: "pie", // 饼图
                        //起始刻度的角度，默认为 90 度，即圆心的正上方。0 度为圆心的正右方。
                        startAngle: 180,
                        hoverAnimation: false,
                        tooltip: {},
                        radius: ['130%', '150%'], // 饼图的半径**(内圆和外圆半径)
                        center: ['48%', '80%'], // 饼图的中心（圆心）坐标
                        labelLine: {
                            normal: {
                                show: false
                            }
                        },
                        data: [{
                            value: already_speed,
                            itemStyle: {
                                color: new echarts.graphic.LinearGradient(
                                    // (x1,y2) 点到点 (x2,y2) 之间进行渐变
                                    0, 0, 0, 1, [{
                                            offset: 0,
                                            color: '#00fffb'
                                        }, // 0 起始颜色
                                        {
                                            offset: 1,
                                            color: '#0061ce'
                                        } // 1 结束颜色
                                    ]
                                )
                            }
                        }, {
                            value: not_speed,
                            itemStyle: {
                                color: '#12274d'
                            }
                        }, {
                            value: 200,
                            itemStyle: {
                                color: 'transparent'
                            }
                        }]
                    }]
                };
                month_sales_speed_chart.setOption(month_sales_speed_option);
                // 数据赋值
                $('.quarter .sales-price').text(res.data.month_sales_speed.current_month);
                $('.quarter .increase').text(res.data.month_sales_speed.increase + '%');
                $('.quarter .speed').html(res.data.month_sales_speed.speed + '<small> %</small>');
                // 做监听,不会覆盖之前的window.onresize 的方法
                window.addEventListener('resize', function() {
                    month_sales_speed_chart.resize();
                });




                // 最右侧全国热榜
                var color_all = ['#d93f36', '#68d8fe', '#4c9bfd'];
                $('.top .all ul').empty();
                res.data.national_hot.goods_hot.forEach((obj, index) => {
                    var idx = index + 1;
                    var the_div = `<li title="${obj.title}">
                            <i class="icon-cup${idx}" style="color: ${color_all[index]};"></i>
                            ${obj.title}
                          </li>`;
                    $('.top .all ul').append(the_div)
                });
                if(res.data.national_hot.province.length > 0) {
                    // 1. 渲染左侧 各省热销 的布局
                    $('.top .sup').empty();
                    res.data.national_hot.province.forEach((obj, index) => {
                        var the_left_li = `<li class="${index === 0 ? 'active' : ''}">
                                  <span title="${obj.name}">${obj.name}</span>
                                  <span>${obj.sales} <s class="${obj.flag ? 'icon-up' : 'icon-down'}"></s></span>
                                  </li>`;
                        $('.top .sup').append(the_left_li);
                    });

                    // 2.渲染右侧的数据 近三十日  默认显示的是北京的数据 
                    $('.top .sub').empty();
                    res.data.national_hot.province[0].goods.forEach((obj, index) => {
                        var the_right_li = `<li>
                                    <span title="${obj.title}">${obj.title}</span>
                                    <span>${obj.count}</span><s class="${obj.flag ? 'icon-up' : 'icon-down'}"></s>
                                  </li>`;
                        $('.top .sub').append(the_right_li);
                    });
                }

                // 3.给左侧li注册鼠标移入事件
                $('.top .sup li').hover(function() {
                    // 清除定时器
                    clearInterval(national_hot_timer);

                    // --------- 同步下标 ------
                    national_hot_now_index = $(this).index()

                    // 3.1 添加高亮
                    $(this).addClass('active').siblings().removeClass('active');
                    // 3.2获取下标
                    var index = $(this).index();

                    // 先清空 再渲染
                    $('.top .sub').empty();

                    // 3.3 切换数据
                    $('.top .sub').empty();
                    res.data.national_hot.province[index].goods.forEach((obj, index) => {
                        var the_right_li = `<li>
                              <span title="${obj.title}">${obj.title}</span>
                              <span>${obj.count}</span><s class="${obj.flag ? 'icon-up' : 'icon-down'}"></s>
                            </li>`;
                        $('.top .sub').append(the_right_li);
                    })

                }, function() {
                    // 鼠标移出事件
                    national_hot_interval(); // 重新执行定时器
                });
                // 自动切换
                function national_hot_interval() {
                    national_hot_timer = setInterval(() => {
                        national_hot_now_index++
                        if (national_hot_now_index === $('.sup li').length) {
                            national_hot_now_index = 0
                        }

                        // 明确 : 实现的效果 ---- 自动切换 
                        // 主动触发左侧li的鼠标移入事件 ---- 清除定时器
                        $('.top .sup li').eq(national_hot_now_index).trigger('mouseenter')
                            // 主动触发左侧li的鼠标移出事件 ---- 重启定时器
                        $('.top .sup li').eq(national_hot_now_index).trigger('mouseleave')
                    }, 3000);
                }
                national_hot_interval();





                // 中国地图
                var region_map_chart = echarts.init(document.querySelector('.map .geo'), 'macarons');
                var total = res.data.region_map.map(function(item) {
                        return item.value;
                    }).reduce((a, b) => a + b);
                var geo_coord_map = {
                    '北京': [116.46, 39.92],
                    '上海': [121.48, 31.22],
                    '天津': [117.2, 39.13],
                    '重庆': [106.54, 29.59],
                    '河北': [114.48, 38.03],
                    '山西': [112, 37],
                    '辽宁': [123.38, 41.8],
                    '吉林': [125.35, 43.88],
                    '黑龙江': [126.63, 47.3],
                    '浙江': [120.19, 29],
                    '福建': [118.5, 26.08],
                    '山东': [117.78, 36.5],
                    '河南': [113.65, 34.76],
                    '湖北': [112, 31],
                    '湖南': [111, 28.21],
                    '广东': [113.23, 23.5],
                    '海南': [110, 19.02],
                    '四川': [102.06, 30.67],
                    '贵州': [106.71, 26.57],
                    '云南': [100, 25],
                    '江西': [115.89, 28.68],
                    '陕西': [108.95, 34.27],
                    '青海': [97.74, 36.56],
                    '甘肃': [103.73, 36.03],
                    '广西': [108.54, 23.59],
                    '新疆': [87.68, 43.77],
                    '内蒙古': [111.65, 41.82],
                    '西藏': [91.11, 29.97],
                    '宁夏': [106.27, 38.47],
                    '台湾': [121, 24],
                    '香港': [114.1, 22.2],
                    '澳门': [113.33, 22.13],
                    '安徽': [117.27, 32],
                    '江苏': [119.5, 33.5],
                    '南海': [127.6, 24.6]
                };
                var series = [{
                    type: 'effectScatter',
                    coordinateSystem: 'geo',
                    zlevel: 2,
                    rippleEffect: {
                        brushType: 'stroke'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: 'right',
                            formatter: '{b}'
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#3ed4ff'
                        }
                    },
                    // 波纹大小处理
                    symbolSize: function (val) {
                      if(val != undefined && val[2] != undefined) {
                        return ((val[2] / total)*100)/2;
                      }
                    },
                    data: res.data.region_map.map(function(item) {
                        if (geo_coord_map[item.name] != undefined) {
                            return {
                                name: item.name,
                                value: geo_coord_map[item.name].concat([item.value])
                            };
                        }
                    })
                }];
                var region_map_option = {
                    backgroundColor: '#080a20',
                    tooltip: {
                        trigger: 'item',
                        formatter: function (params) {
                            return params.data.name+': '+params.data.value[2];
                        }
                    },
                    geo: {
                        // 地理坐标
                        map: 'china',
                        label: {
                            emphasis: {
                                show: true,
                                color: '#0d97bf'
                            }
                        },
                        roam: false, // 是否开启鼠标缩放和平移漫游
                        zoom: 1.2, // 当前视角的缩放比例
                        itemStyle: {
                            normal: {
                                areaColor: '#132937',
                                borderColor: '#0692a4'
                            },
                            emphasis: {
                                areaColor: '#0b1c2d'
                            }
                        }
                    },
                    series: series
                };
                region_map_chart.setOption(region_map_option);
                // 做监听,不会覆盖之前的window.onresize 的方法
                window.addEventListener('resize', function() {
                    region_map_chart.resize();
                });
                
                // 美国地图
                // $.get( $('body').data('public-host')+'/static/plugins/databoard/js/admin/template1/usa.json', function (json) {
                // echarts.registerMap('map', json);
                //     var region_map_option = {
                //         tooltip: {
                //         trigger: 'item',
                //         showDelay: 0,
                //         transitionDuration: 0.2
                //         },
                //         series: [
                //             {
                //                 type: 'map',
                //                 roam: true,
                //                 map: 'map',
                //                 emphasis: {
                //                 label: {
                //                     show: true
                //                 }
                //                 },
                //                 data: [
                //                     { name: 'Alabama', value: 4822023 },
                //                     { name: 'Alaska', value: 731449 },
                //                     { name: 'Arizona', value: 6553255 },
                //                     { name: 'Arkansas', value: 2949131 },
                //                     { name: 'California', value: 38041430 },
                //                     { name: 'Colorado', value: 5187582 },
                //                     { name: 'Connecticut', value: 3590347 },
                //                     { name: 'Delaware', value: 917092 },
                //                     { name: 'District of Columbia', value: 632323 },
                //                     { name: 'Florida', value: 19317568 },
                //                     { name: 'Georgia', value: 9919945 },
                //                     { name: 'Hawaii', value: 1392313 },
                //                     { name: 'Idaho', value: 1595728 },
                //                     { name: 'Illinois', value: 12875255 },
                //                     { name: 'Indiana', value: 6537334 },
                //                     { name: 'Iowa', value: 3074186 },
                //                     { name: 'Kansas', value: 2885905 },
                //                     { name: 'Kentucky', value: 4380415 },
                //                     { name: 'Louisiana', value: 4601893 },
                //                     { name: 'Maine', value: 1329192 },
                //                     { name: 'Maryland', value: 5884563 },
                //                     { name: 'Massachusetts', value: 6646144 },
                //                     { name: 'Michigan', value: 9883360 },
                //                     { name: 'Minnesota', value: 5379139 },
                //                     { name: 'Mississippi', value: 2984926 },
                //                     { name: 'Missouri', value: 6021988 },
                //                     { name: 'Montana', value: 1005141 },
                //                     { name: 'Nebraska', value: 1855525 },
                //                     { name: 'Nevada', value: 2758931 },
                //                     { name: 'New Hampshire', value: 1320718 },
                //                     { name: 'New Jersey', value: 8864590 },
                //                     { name: 'New Mexico', value: 2085538 },
                //                     { name: 'New York', value: 19570261 },
                //                     { name: 'North Carolina', value: 9752073 },
                //                     { name: 'North Dakota', value: 699628 },
                //                     { name: 'Ohio', value: 11544225 },
                //                     { name: 'Oklahoma', value: 3814820 },
                //                     { name: 'Oregon', value: 3899353 },
                //                     { name: 'Pennsylvania', value: 12763536 },
                //                     { name: 'Rhode Island', value: 1050292 },
                //                     { name: 'South Carolina', value: 4723723 },
                //                     { name: 'South Dakota', value: 833354 },
                //                     { name: 'Tennessee', value: 6456243 },
                //                     { name: 'Texas', value: 26059203 },
                //                     { name: 'Utah', value: 2855287 },
                //                     { name: 'Vermont', value: 626011 },
                //                     { name: 'Virginia', value: 8185867 },
                //                     { name: 'Washington', value: 6897012 },
                //                     { name: 'West Virginia', value: 1855413 },
                //                     { name: 'Wisconsin', value: 5726398 },
                //                     { name: 'Wyoming', value: 576412 },
                //                     { name: 'Puerto Rico', value: 3667084 }
                //                 ]
                //             }
                //         ]
                //     };
                //     region_map_chart.setOption(region_map_option);
                // });

                // 日本地图
                // $.get( $('body').data('public-host')+'/static/plugins/databoard/js/admin/template1/japan.json', function (json) {
                // echarts.registerMap('map', json);
                //     var region_map_option = {
                //         tooltip: {
                //         trigger: 'item',
                //         showDelay: 0,
                //         transitionDuration: 0.2
                //         },
                //         series: [
                //             {
                //                 type: 'map',
                //                 roam: true,
                //                 map: 'map',
                //                 emphasis: {
                //                 label: {
                //                     show: true
                //                 }
                //                 },
                //                 data: [
                //                     { name: 'Alabama', value: 4822023 },
                //                     { name: 'Alaska', value: 731449 },
                //                     { name: 'Arizona', value: 6553255 },
                //                     { name: 'Arkansas', value: 2949131 },
                //                     { name: 'California', value: 38041430 },
                //                     { name: 'Colorado', value: 5187582 },
                //                     { name: 'Connecticut', value: 3590347 },
                //                     { name: 'Delaware', value: 917092 },
                //                     { name: 'District of Columbia', value: 632323 },
                //                     { name: 'Florida', value: 19317568 },
                //                     { name: 'Georgia', value: 9919945 },
                //                     { name: 'Hawaii', value: 1392313 },
                //                     { name: 'Idaho', value: 1595728 },
                //                     { name: 'Illinois', value: 12875255 },
                //                     { name: 'Indiana', value: 6537334 },
                //                     { name: 'Iowa', value: 3074186 },
                //                     { name: 'Kansas', value: 2885905 },
                //                     { name: 'Kentucky', value: 4380415 },
                //                     { name: 'Louisiana', value: 4601893 },
                //                     { name: 'Maine', value: 1329192 },
                //                     { name: 'Maryland', value: 5884563 },
                //                     { name: 'Massachusetts', value: 6646144 },
                //                     { name: 'Michigan', value: 9883360 },
                //                     { name: 'Minnesota', value: 5379139 },
                //                     { name: 'Mississippi', value: 2984926 },
                //                     { name: 'Missouri', value: 6021988 },
                //                     { name: 'Montana', value: 1005141 },
                //                     { name: 'Nebraska', value: 1855525 },
                //                     { name: 'Nevada', value: 2758931 },
                //                     { name: 'New Hampshire', value: 1320718 },
                //                     { name: 'New Jersey', value: 8864590 },
                //                     { name: 'New Mexico', value: 2085538 },
                //                     { name: 'New York', value: 19570261 },
                //                     { name: 'North Carolina', value: 9752073 },
                //                     { name: 'North Dakota', value: 699628 },
                //                     { name: 'Ohio', value: 11544225 },
                //                     { name: 'Oklahoma', value: 3814820 },
                //                     { name: 'Oregon', value: 3899353 },
                //                     { name: 'Pennsylvania', value: 12763536 },
                //                     { name: 'Rhode Island', value: 1050292 },
                //                     { name: 'South Carolina', value: 4723723 },
                //                     { name: 'South Dakota', value: 833354 },
                //                     { name: 'Tennessee', value: 6456243 },
                //                     { name: 'Texas', value: 26059203 },
                //                     { name: 'Utah', value: 2855287 },
                //                     { name: 'Vermont', value: 626011 },
                //                     { name: 'Virginia', value: 8185867 },
                //                     { name: 'Washington', value: 6897012 },
                //                     { name: 'West Virginia', value: 1855413 },
                //                     { name: 'Wisconsin', value: 5726398 },
                //                     { name: 'Wyoming', value: 576412 },
                //                     { name: 'Puerto Rico', value: 3667084 }
                //                 ]
                //             }
                //         ]
                //     };
                //     region_map_chart.setOption(region_map_option);
                // });
            } else {
                Prompt(res.msg);
            }
        },
        error: function(res) {
            Prompt(res.msg);
        }
    });
}