$(function()
{
    // 拖拽
    $('ul.forth-selection-content-goods').dragsort({ dragSelector: 'a', placeHolderTemplate: '<li class="drag-sort-dotted"></li>'});

    // 添加元素到右侧
    function RightElementAdd(gid, name, price, url, img)
    {
        if($('.forth-selection-container ul.ul-right').find('.items-li-'+gid).length == 0)
        {
            var html = '<li class="am-animation-slide-bottom items-li-'+gid+'">';
                html += '<input type="hidden" name="goods['+gid+'][goods_id]" value="'+gid+'" />';
                html += '<a href="'+url+'" target="_blank" class="am-text-truncate am-padding-0"><img src="'+img+'" width="30" height="30" class="am-img-thumbnail am-radius" /> <span>'+name+'</span></a>';
                html += ' <input type="number" name="goods['+gid+'][discount_rate]" step="0.01" min="0" max="0.99" class="am-form-field am-radius" placeholder="折扣" />';
                html += ' <input type="number" name="goods['+gid+'][dec_price]" step="0.01" min="0" class="am-form-field am-radius" placeholder="减金额" />';
                html += ' <input name="goods['+gid+'][is_recommend]" value="1" type="checkbox" class="switch-checkbox" data-off-text="不推荐" data-on-text="推荐" data-size="xs" data-on-color="success" data-off-color="default" data-handle-width="50" data-am-switch />';
                html += '<i class="iconfont icon-delete am-fr"></i>';
                html += '</li>';
            $('.forth-selection-container ul.ul-right').append(html);
            $('.forth-selection-container ul.ul-right .items-li-'+gid+' a').popover({content: '价格'+__currency_symbol__+price, trigger: 'hover focus', theme: 'sm'});
            SwitchInit();
        }

        // 右侧数据同步
        RightElementGoods();

        // 左侧是否还有内容
        if($('.forth-selection-container ul.ul-left li').length == 0)
        {
            $('.forth-selection-container ul.ul-left .table-no').removeClass('none');
        } else {
            $('.forth-selection-container ul.ul-left .table-no').addClass('none');
        }
    }

    // 批量-商品id同步
    function RightElementGoods()
    {
        var value_all = [];
        $('.forth-selection-container ul.ul-right li').each(function(k, v)
        {
            value_all[k] = $(this).find('span.name').data('value');
        });
        $('.forth-selection-container input[name="goods_ids"]').val(value_all.join(',')).blur();

        // 右侧是否还有数据
        if($('.forth-selection-container ul.ul-right li').length == 0)
        {
            $('.forth-selection-container ul.ul-right .table-no').removeClass('none');
        } else {
            $('.forth-selection-container ul.ul-right .table-no').addClass('none');
        }
    }
    // 左侧点击到右侧
    $('.forth-selection-container ul.ul-left').on('click', 'i.icon-angle-right', function()
    {
        var $this = $(this).prev();
        var gid = $this.data('gid');
        var price = $this.data('price');
        var url = $this.data('url');
        var img = $this.data('img');
        var name = $this.text();
        $(this).parent().remove();
        RightElementAdd(gid, name, price, url, img);
    });

    // 左侧全部移动到右侧
    $('.forth-selection-container .selected-all').on('click', function()
    {
        $('.forth-selection-container ul.ul-left li').each(function(k, v)
        {
            var $this = $(this).find('span');
            var gid = $this.data('gid');
            var price = $this.data('price');
            var url = $this.data('url');
            var img = $this.data('img');
            var name = $this.text();
            $(this).remove();
            RightElementAdd(gid, name, price, url, img);
        });
    });

    // 右侧删除
    $('.forth-selection-container ul.ul-right').on('click', 'i.icon-delete', function()
    {
        $(this).parent().remove();
        RightElementGoods();
    });

    // 商品搜索
    $('.forth-selection-form .search-submit').on('click', function()
    {
        var category_id = $('.forth-selection-form .forth-selection-form-category').val() || '';
        var keywords = $('.forth-selection-form .forth-selection-form-keywords').val() || '';

        // ajax请求
        $.ajax({
            url:$('.forth-selection-form').data('search-url'),
            type:'POST',
            dataType:"json",
            timeout:10000,
            data:{"category_id": category_id, "keywords": keywords},
            success:function(result)
            {
                if(result.code == 0)
                {
                    var html = '';
                    $('ul.ul-left li').remove();
                    if(result.data.length > 0)
                    {
                        for(var i in result.data)
                        {
                            html += '<li class="am-animation-slide-bottom"><span data-gid="'+result['data'][i]['id']+'" data-price="'+result['data'][i]['price']+'" data-url="'+result['data'][i]['goods_url']+'" data-img="'+result['data'][i]['images']+'">'+result['data'][i]['title']+'</span><i class="iconfont icon-angle-right am-fr"></i></li>';
                        }
                        $('ul.ul-left').append(html);
                        $('ul.ul-left .table-no').addClass('none');
                    } else {
                        $('ul.ul-left .table-no').removeClass('none');
                    }
                } else {
                    Prompt(result.msg);
                }
            },
            error:function()
            {
                Prompt('网络异常错误');
            }
        });
    });
});