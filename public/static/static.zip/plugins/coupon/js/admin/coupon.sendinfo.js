/**
 * 用户搜索
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2022-07-17
 * @desc    description
 */
function UserQuery()
{
    var level_id = $('.level-search-container select').val() || 0;
    var keywords = $('.user-search-container input.user-input-keywords').val() || '';
    $.ajax({
        url:$('.search-container').data('search-url'),
        type:'POST',
        dataType:"json",
        timeout:10000,
        data:{level_id: level_id, keywords: keywords},
        success:function(result)
        {
            $('.not-user-panel .table-no').hide();
            if(result.code == 0)
            {
                $('.not-user-panel ul.user-items').html(result.data);
            } else {
                Prompt(result.msg);
            }
        },
        error:function()
        {
            Prompt('网络异常错误');
        }
    });
}

$(function()
{
    // 添加用户
    $(document).on('click', '.not-user-panel ul.user-items .submit-icon', function() {
        var user_id = $(this).data('user-id') || null;
        var user_view = $(this).data('user-view') || '用户昵称';
        var user_avatar = $(this).data('user-avatar') || '';
        if(user_id == null)
        {
            Prompt('用户id有误');
            return false;
        }

        // 添加到已选择用户列表，重复则跳过
        if($('.already-user-panel ul.user-items').find('.already-user-'+user_id).length <= 0)
        {
            var html = '<li class="am-text-center am-padding-sm am-animation-slide-right already-user-'+user_id+'">';
                html += '<input type="hidden" name="user_ids[]" value="'+user_id +'" />';
                html += '<i class="submit-icon am-icon-times am-text-danger"></i>';
                html += '<div class="items am-padding-sm">';
                html += '<img src="'+user_avatar+'" alt="'+user_view+'" class="am-img-thumbnail am-circle am-block" />';
                html += '<p class="am-text-truncate am-margin-top-xs">'+user_view+'</p>';
                html += '</div>';
                html += '</li>';
            $('.already-user-panel ul.user-items').append(html);
            $('.already-user-panel .table-no').hide();
        }
        $(this).parent().remove();

        // 是否还有未选择用户
        if($('.not-user-panel ul.user-items li').length <= 0)
        {
            $('.not-user-panel .table-no').show();
        }
    });

    // 已选择用户删除
    $(document).on('click', '.already-user-panel ul.user-items .submit-icon', function()
    {
        $(this).parent().remove();

        // 是否还有数据
        if($('.already-user-panel ul.user-items li').length <= 0)
        {
            $('.already-user-panel .table-no').show();
        }
    });

    // 用户搜索
    $('.user-search-container .am-input-group-btn').on('click', function()
    {
        UserQuery();
    });

    // 用户搜索框输入框回车事件
    $('.user-search-container input.user-input-keywords').on('keydown', function(event)
    {
        if(event.keyCode == 13)
        {
            UserQuery();
            return false;
        }
    });
});