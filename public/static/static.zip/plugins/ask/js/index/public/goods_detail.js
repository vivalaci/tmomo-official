$(function () {
    getAskData(1);
    $(document).on('click', '.ask-page-container .pagelibrary a', function() {
        var page = $(this).data('page') || null;
        if(page != null)
        {
            // 获取数据
            getAskData(page);

            // 回到顶部位置
            $(window).smoothScroll({position: $('.getAskData-container').offset().top});
        }
    });
    // 显示隐藏回答
    $(document).on('click','.comment-base .view-more-open', function() {
        var self = $(this);
        var $commentItem = self.parents('.comment-item');
        //当前页
        var page = parseInt(self.attr('data-page') || 0) + 1;
        // 总页数
        var pageTotal = parseInt(self.attr('data-page-total') || 1);
        // 标记是否收起了回答 1为收起了，0为未收起
        var hideMark = parseInt(self.attr('data-hide-mark') || 0);
        if(hideMark === 1 || page > pageTotal){
            if(page > pageTotal){
                self.addClass('am-hide').siblings().removeClass('am-hide');
            }else{
                self.siblings().removeClass('am-hide');
            }
        }else{
            $.AMUI.progress.start();
            $.ajax({
                url: RequestUrlHandle(self.parents('.comment-base').data('comments-reply-url')),
                type: 'POST',
                dataType: 'json',
                timeout: 60000,
                data: {
                    ask_id: $commentItem.find('.ask-item').attr('data-id'),
                    ask_comments_id: 0,
                    page: page
                },
                success: function (result) {
                    $.AMUI.progress.done();
                    if (result.code == 0) {
                        // 评论展示
                        // 按钮文本改变
                        if (page == 1) {
                            self.html(self.data('text') + '<i class="am-icon-angle-down"></i>');
                            $commentItem.find('.answer-list').empty().append(result.data.data);
                        }else{
                            $commentItem.find('.answer-list').append(result.data.data);
                        }

                        // 无数据则隐藏按钮
                        if (result.data.page >= result.data.page_total) {
                            self.addClass('am-hide').siblings().removeClass('am-hide');
                        }else{
                            self.siblings().removeClass('am-hide');
                        }
                        // 分页值记录
                        self.attr('data-page', page);
                        self.attr('data-page-total', result.data.page_total);
                    } else {
                        Prompt(result.msg);
                    }
                },
                error: function (xhr, type) {
                    $.AMUI.progress.done();
                    Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
                }
            });
        }
        $commentItem.find('.answer-list').find('.answer-item').removeClass('am-hide');
        self.attr('data-hide-mark', 0);
    });
    $(document).on('click','.comment-base .view-more-colse', function() {
        $(this).parents('.answer-content').find('.answer-item').eq(0).siblings().addClass('am-hide');
        $(this).addClass('am-hide').siblings().removeClass('am-hide').attr('data-hide-mark',1);
    });
})

/**
 * 问答分页数据查询
 * @author   kevin
 * @blog     http://gong.gg/
 * @version  1.0.0
 * @datetime 2024-10-18T21:39:55+0800
 * @param    {[int]}  page [分页值]
 */
function getAskData (page) {
    if($('.ask-container').length > 0) {
        $.ajax({
            url: RequestUrlHandle($('.ask-container').data('ajax-url')),
            type: 'post',
            dataType: "json",
            timeout: 10000,
            data: {"page": page || 1},
            success: function (res) {
                if (res.code == 0) {
                    $('.ask-container').html(res.data.data);
                    $('.ask-page-container').html(PageLibrary(res.data.total, res.data.number, page, 2));
                } else {
                    Prompt(res.msg);
                }
            },
            error: function (xhr, type) {
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    }
}