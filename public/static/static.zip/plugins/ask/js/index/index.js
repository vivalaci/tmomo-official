// 问答页面
var $ask = $('.plugins-ask');
var $comments_reply_obj = null;

/**
 * 问答评论回复展示
 * @author  Devil
 * @ask    http://gong.gg/
 * @version 1.0.0
 * @date    2022-12-20
 * @desc    description
 * @param   {[array]}        data       [评论数据]
 * @param   {[object]}       e          [当前操作元素对象]
 * @param   {[boolean]}      is_first   [前面展示]
 */
function PluginsAskCommentsReplyView (data, e, is_first = false) {
    if ((data || null) != null && data.length > 0) {
        var is_give_thumbs = parseInt($ask.data('is-give-thumbs') || 0);
        e.parent().parent().parent().find('>.am-collapse').collapse('toggle');
        e.parent().parent().parent().find('>.am-this-open').removeClass('toggle-mark' + ((e.data('reply-comments-id') || 0) + (e.data('ask-comments-id') || 0) + e.data('ask-id')) + ' am-this-open am-in');
        var $list = e.parents('li').find('.reply-comments-list');
        var reply_name = $ask.data('text-reply-name');
        var give_thumbs_name = $ask.data('text-give-thumbs-name');
        for (var i in data) {
            var html = `<div class="item am-margin-top-lg am-flex am-flex-justify-between">
                    <img src="`+ data[i]['user']['avatar'] + `" class="am-img-thumbnail am-circle am-fl" />
                    <div class="am-fr right-content">
                        <div class="comments-reply-base am-nbfc">
                            <span class="username">`+ data[i]['user']['user_name_view'] + `</span>
                            <span class="am-color-grey am-margin-left-sm">`+ data[i]['add_time'] + `</span>
                            <div class="am-fr right-content-operate">
                                <a href="javascript:;" class="am-color-grey-dark `+ (__user_id__ == 0 ? 'login-event' : 'comments-submit') + `" data-ask-id="` + data[i]['ask_id'] + `" data-ask-comments-id="` + data[i]['ask_comments_id'] + `" data-reply-comments-id="` + data[i]['id'] + `" data-value="` + data[i]['comments_count'] + `" data-text="` + reply_name + `"><i class="iconfont icon-recover"></i> ` + reply_name + `(<font>` + data[i]['comments_count'] + `</font>)</a>`;
            if (is_give_thumbs == 1) {
                html += `<a href="javascript:;" class="am-color-grey-dark am-fr ` + (__user_id__ == 0 ? 'login-event' : 'give-thumbs-submit') + ` ` + (data[i]['is_give_thumbs'] == 1 ? 'am-active' : '') + `" data-ask-id="` + data[i]['ask_id'] + `" data-ask-comments-id="` + data[i]['id'] + `" data-reply-comments-id="` + data[i]['ask_comments_id'] + `" data-text="` + give_thumbs_name + `"><i class="iconfont ` + (data[i]['is_give_thumbs'] == 1 ? 'icon-a-givealike-tap-review' : 'icon-a-givealike-review') + `"></i> ` + give_thumbs_name + `(<font>` + data[i]['give_thumbs_count'] + `</font>)</a>`;
            }
            html += `</div>
                        </div>`;
            if ((data[i]['reply_comments_text'] || null) != null) {
                html += `<div class="am-alert am-radius reply-comments-text">` + data[i]['reply_comments_text'] + `</div>`;
            }
            html += `
                    <p class="am-margin-top-xs reply-content">`+ data[i]['content'] + `</p>
                    <div class="am-ask-comments-input am-panel-collapse am-collapse"></div>
                    </div>
                </div>`;
            if (is_first) {
                $list.prepend(html);
            } else {
                $list.append(html);
            }
        }
        // 仅前面追加处理数据、表示为当前回复增加的
        if (is_first) {
            // 当操作的评论数量
            var count = data.length;
            var v1 = parseInt(e.attr('data-value') || 0) + count;
            e.find('font').text(v1);
            e.attr('data-value', v1);
            // 是否回复操作、则更新评论数量
            if (e.parents('.reply-comments-list').length > 0) {
                var $comments_btm = e.parents('li').find('.right-content .comments-base .right-content-operate .comments-submit');
                var v2 = parseInt($comments_btm.attr('data-value') || 0) + count;
                $comments_btm.text(' ' + $comments_btm.data('text') + '(' + v2 + ')');
                $comments_btm.attr('data-value', v2);
            }
            // 查看全部回复数量
            var $all_btn = e.parents('li').find('.view-comments-reply-submit');
            if ($all_btn.length > 0) {
                var v3 = parseInt($all_btn.attr('data-value') || 0) + count;
                $all_btn.find('.num').text(v3);
                $all_btn.attr('data-value', v3);
            }
        }
    }
}

/**
 * 问答评论展示
 * @author  Devil
 * @ask    http://gong.gg/
 * @version 1.0.0
 * @date    2022-12-20
 * @desc    description
 * @param   {[array]}        data       [评论数据]
 * @param   {[boolean]}      is_first   [前面展示]
 */
function PluginsAskCommentsView (data, is_first = false) {
    if ((data || null) != null && data.length > 0) {
        var is_give_thumbs = parseInt($ask.data('is-give-thumbs') || 0);
        var $comments = $('.comments-list');
        $comments.removeClass('am-hide');
        var $list = $comments.find('ul');
        var reply_name = $ask.data('text-reply-name');
        var give_thumbs_name = $ask.data('text-give-thumbs-name');
        for (var i in data) {
            var html = `<li class="am-padding-vertical-main am-flex am-flex-justify-between">
                    <img src="`+ data[i]['user']['avatar'] + `" class="am-img-thumbnail am-circle" />
                    <div class="right-content am-text-sm">
                        <div class="comments-base am-nbfc">
                            <span class="username am-font-weight">`+ data[i]['user']['user_name_view'] + `</span>
                            <span class="am-color-grey am-margin-left-sm">`+ data[i]['add_time'] + `</span>
                            <div class="am-fr right-content-operate">
                                <a href="javascript:;" class="am-color-grey-dark `+ (__user_id__ == 0 ? 'login-event' : 'comments-submit') + `" data-ask-id="` + data[i]['ask_id'] + `" data-ask-comments-id="` + data[i]['id'] + `" data-value="` + data[i]['comments_count'] + `" data-text="` + reply_name + `"><i class="iconfont icon-recover"></i> ` + reply_name + `(<font>` + data[i]['comments_count'] + `</font>)</a>`;
            if (is_give_thumbs == 1) {
                html += `<a href="javascript:;" class="am-color-grey-dark am-fr ` + (__user_id__ == 0 ? 'login-event' : 'give-thumbs-submit') + ` ` + (data[i]['is_give_thumbs'] == 1 ? 'am-active' : '') + `" data-ask-id="` + data[i]['ask_id'] + `" data-ask-comments-id="` + data[i]['id'] + `" data-text="` + give_thumbs_name + `"><i class="iconfont ` + (data[i]['is_give_thumbs'] == 1 ? 'icon-a-givealike-tap-review' : 'icon-a-givealike-review') + `"></i> ` + give_thumbs_name + `(<font>` + data[i]['give_thumbs_count'] + `</font>)</a>`;
            }
            html += `</div>
                        </div>
                        <p class="am-margin-top-xs comments-content">`+ data[i]['content'] + `</p>
                        <div class="am-ask-comments-input am-panel-collapse am-collapse"></div>
                        <div class="reply-comments-list"></div>
                    </div>
                </li>`;
            if (is_first) {
                $list.prepend(html);
            } else {
                $list.append(html);
            }
        }
        // 仅前面追加处理数据、表示为当前评论增加的
        if (is_first) {
            // 总数
            var $btn_val = $('.view-all-comments-submit');
            var count = parseInt($btn_val.attr('data-value') || 0) + data.length;
            $btn_val.find('.comments-num').text(count);
            $btn_val.attr('data-value', count);
            var $comments_btn = $('.detail-bottom-container .comments-submit');
            var $comments_title = $('.comments-title');
            $comments_btn.find('font').text(count);
            $comments_btn.attr('data-value', count);
            $comments_title.find('font').text((Number($comments_title.find('font').text()) || 0) + data.length);
        }
    }
}

$(function () {
    // 表情选择开启
    var cursor_pos = 0;
    $(document).on('click', '.emoji-submit', function () {
        var $parent = $(this).parents('form');
        var $obj = $parent.find('.emoji-container');
        var display = $obj.css('display');
        if (display == 'none') {
            cursor_pos = CursorPos($parent.find('textarea'));
            $obj.show();
        } else {
            $obj.hide();
        }
    });
    // 表情选择确认
    $(document).on('click', '.emoji-container ul li a', function () {
        var $parent = $(this).parents('form');
        var old_val = $parent.find('textarea').val();
        var tmp1 = old_val.substring(0, cursor_pos);
        var tmp2 = old_val.substring(cursor_pos, old_val.length);
        var new_val = tmp1 + $(this).text() + tmp2;
        $parent.find('textarea').val(new_val).focus();
        $parent.find('textarea').trigger('input');
        $(this).parents('.emoji-container').hide();
    });
    $(document).on('click', '.emoji-container .am-close', function () {
        $(this).parents('.emoji-container').hide();
    });

    // 评论输入长度处理
    $(document).on('keyup change blur', '.reply-container textarea, .modal-reply-container textarea, .am-comments-container textarea', function () {
        var max = parseInt($(this).attr('maxlength') || 0);
        if (max > 0) {
            $(this).parent().find('.comments-length-value').text(max - $(this).val().trim().length);
        }
    });

    // 评论回复事件
    $(document).on('click', '.comments-list .comments-submit', function () {
        var self = $(this);
        $comments_reply_obj = self;
        $ask.attr('data-ask-id', self.data('ask-id'));
        $ask.attr('data-ask-comments-id', self.data('ask-comments-id') || 0);
        $ask.attr('data-reply-comments-id', self.data('reply-comments-id') || 0);
        self.parent().parent().parent().find('.am-collapse').empty();
        var html = $('.am-comments-container').html();
        self.parent().parent().parent().find('>.am-collapse').append(html);
        $('.am-ask-comments-input').each(function () {
            if($(this).hasClass('am-this-open')){
                $(this).collapse('toggle');
                $(this).removeClass('am-this-open am-in');
            }
        });
        if (self.parent().parent().parent().find('>.am-collapse').hasClass('am-this-open')) {
            self.parent().parent().parent().find('>.am-collapse').collapse('toggle');
            self.parent().parent().parent().find('>.am-collapse').removeClass('toggle-mark' + ((self.data('reply-comments-id') || 0) + (self.data('ask-comments-id') || 0)  + self.data('ask-id')) + ' am-this-open am-in');
        } else {
            self.parent().parent().parent().find('>.am-collapse').addClass('toggle-mark' + ((self.data('reply-comments-id') || 0) + (self.data('ask-comments-id') || 0)  + self.data('ask-id')) + ' am-this-open');
            self.parent().parent().parent().find('>.am-collapse').collapse('toggle');
            setTimeout(()=>{
                self.parent().parent().parent().find('>.am-this-open textarea').focus();
            },500)
        }
    });

    // 问答点赞
    $(document).on('click', '.give-thumbs-submit', function () {
        var $this = $(this);
        $.AMUI.progress.start();
        $.ajax({
            url: RequestUrlHandle($('.plugins-ask').data('givethumbs-url')),
            type: 'POST',
            dataType: 'json',
            timeout: 60000,
            data: {
                ask_id: $this.attr('data-ask-id') || 0,
                ask_comments_id: $this.attr('data-ask-comments-id') || 0,
                reply_comments_id: $this.attr('data-reply-comments-id') || 0
            },
            success: function (result) {
                $.AMUI.progress.done();
                if (result.code == 0) {
                    if (result.data.is_active == 1) {
                        $this.addClass('am-active');
                        if ($this.find('i')) {
                            $this.find('i').removeClass('icon-a-givealike-review').addClass('icon-a-givealike-tap-review')
                        }
                    } else {
                        $this.removeClass('am-active');
                        if ($this.find('i')) {
                            $this.find('i').addClass('icon-a-givealike-review').removeClass('icon-a-givealike-tap-review')
                        }
                    }
                    $this.find('font').text(result.data.count);
                } else {
                    Prompt(result.msg);
                }
            },
            error: function (xhr, type) {
                $.AMUI.progress.done();
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    });

    // 问答评论
    $(document).on('click', '.reply-container button[type="submit"], .modal-reply-container button[type="submit"]', function () {
        // 是否已登录
        if (__user_id__ == 0) {
            return false;
        }

        // 参数配置
        var $form = $(this).parents('form');
        var content = $form.find('textarea').val().trim();
        if (content == '') {
            Prompt($ask.data('text-comments-input-tips') || '请先输入评论内容');
            return false;
        }
        // 问答评论模式下则清除评论和回复id
        var ask_comments_id = $ask.attr('data-ask-comments-id') || 0;
        var reply_comments_id = $ask.attr('data-reply-comments-id') || 0;
        if ($(this).parents('.reply-container').length > 0) {
            ask_comments_id = 0;
            reply_comments_id = 0;
        }

        // ajax
        $.AMUI.progress.start();
        $.ajax({
            url: RequestUrlHandle($ask.data('comments-url')),
            type: 'POST',
            dataType: 'json',
            timeout: 60000,
            data: {
                ask_id: $ask.attr('data-ask-id'),
                ask_comments_id: ask_comments_id,
                reply_comments_id: reply_comments_id,
                content: content
            },
            success: function (result) {
                $.AMUI.progress.done();
                if (result.code == 0) {
                    Prompt(result.msg, 'success');
                    $('.plugins-ask textarea').val('');
                    if ((result.data.ask_comments_id || 0) == 0) {
                        PluginsAskCommentsView([result.data], true);
                        // 如果当前是子页面的时候，则调用父级处理评论
                        if ($('body').hasClass('index-plugins-ask-index-commentsinfo')) {
                            parent.IframePluginsAskCommentsView([result.data]);
                        }
                    } else {
                        PluginsAskCommentsReplyView([result.data], $comments_reply_obj, true);
                        $('.am-collapse').each(function () {
                            $(this).removeClass('am-this-open am-in');
                        });
                    }
                } else {
                    Prompt(result.msg);
                }
            },
            error: function (xhr, type) {
                $.AMUI.progress.done();
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
        return false;
    });

    // 查看回复
    $(document).on('click', '.view-comments-reply-submit, .view-more-comments-submit', function () {
        var $this = $(this);
        var page = parseInt($(this).attr('data-page') || 0) + 1;
        var ask_comments_id = parseInt($(this).data('ask-comments-id') || 0);
        $.AMUI.progress.start();
        $.ajax({
            url: RequestUrlHandle($ask.data('comments-reply-url')),
            type: 'POST',
            dataType: 'json',
            timeout: 60000,
            data: {
                ask_id: $ask.attr('data-ask-id'),
                ask_comments_id: ask_comments_id,
                page: page
            },
            success: function (result) {
                $.AMUI.progress.done();
                if (result.code == 0) {
                    // 评论展示
                    if (ask_comments_id == 0) {
                        $('.comments-list ul').append(result.data.data);
                    } else {
                        // 按钮文本改变
                        if (page == 1) {
                            $this.html('<span>' + $this.data('text') + '</span> <i class="am-icon-angle-down"></i>');
                            $this.parents('li').find('.reply-comments-list').empty().append(result.data.data);
                        }else{
                            $this.parents('li').find('.reply-comments-list').append(result.data.data);
                        }
                    }

                    // 无数据则隐藏按钮
                    if (result.data.page >= result.data.page_total) {
                        $this.addClass('am-hide');
                    }
                    // 分页值记录
                    $this.attr('data-page', page);
                } else {
                    Prompt(result.msg);
                }
            },
            error: function (xhr, type) {
                $.AMUI.progress.done();
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    });

    // 查看所有评论
    $('.view-all-comments-submit, .detail-bottom-container .comments-submit').on('click', function () {
        AMUI.dialog.offcanvas({
            width: 450,
            id: '',
            isClose: true,
            url: $ask.data('commentsinfo-url')
        });
    });
});