$(function()
{
    // 编辑器配置
    var editor_config = [['source', 'undo', 'redo', 'bold', 'italic', 'underline', 'fontborder', 'strikethrough', '|', 'forecolor', 'backcolor', 'link', 'fontsize', 'insertorderedlist', 'insertunorderedlist', '|', 'simpleupload', 'insertimage', 'insertvideo', 'attachment', 'insertframe', 'insertcode', 'emotion']];

    // 编辑器初始化
    if ($('#editor-content').length > 0) {
        UE.getEditor('editor-content', {
            toolbars: editor_config,
            initialFrameHeight: 300
        });
    }
});