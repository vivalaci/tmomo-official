$(function()
{
    // 初始化
    if($('.data-list li').length <= 0)
    {
        $('.brand-bot-data').removeClass('am-hide');
    }

    // 导航切换事件
    $('.brand-nav li .brand-item').on('click', function()
    {
        // 选中
        $('.brand-nav li').removeClass('am-active');
        $(this).parent().addClass('am-active');

        // 数据显隐
        var value = $(this).data('value') || 0;
        if(value == 0)
        {
            $('.data-list li').removeClass('am-hide');
            if($('.data-list li').length <= 0)
            {
                $('.brand-bot-data').removeClass('am-hide');
            } else {
                $('.brand-bot-data').addClass('am-hide');
            }
        } else {
            $('.data-list li').addClass('am-hide');
            $('.data-list li.b-c-'+value).removeClass('am-hide');
            if($('.data-list li.b-c-'+value).length == 0)
            {
                $('.brand-bot-data').removeClass('am-hide');
            } else {
                $('.brand-bot-data').addClass('am-hide');
            }
        }
    });
});