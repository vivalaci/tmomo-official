$(function()
{
    // 批量分账
    $('.submit-settlement').on('click', function()
    {
        // 参数值
        var url = $(this).data('url') || null;
        if(url === null)
        {
            Prompt('url有误');
            return false;
        }

        // 是否有选择的数据
        var values = FromTableCheckedValues('form_checkbox_value', '.am-table-scrollable-horizontal');
        if(values.length <= 0)
        {
            Prompt('请先选中数据');
            return false;
        }

        // 基础信息
        AMUI.dialog.loading({title: '正在处理中、请稍候...'});
        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            timeout: 60000,
            data: {"ids": values},
            success: function(result)
            {
                if(result.code == 0)
                {
                    Prompt(result.msg, 'success');
                    setTimeout(function()
                    {
                        AMUI.dialog.loading('close');
                        window.location.reload();
                    }, 1500);
                } else {
                    AMUI.dialog.loading('close');
                    Prompt(result.msg);
                }
            },
            error: function(xhr, type)
            {
                AMUI.dialog.loading('close');
                Prompt(HtmlToString(xhr.responseText) || '异常错误', null, 30);
            }
        });
    });
});