// 初始化popup表单
FromInit('form.form-validation-import');
$(function()
{
    // 导出模板
    var $goods_form = $('.intellectstools-content form.form-validation');
    $goods_form.find('button[type="submit"]').on('click', function()
    {
        // 释放加载状态
        setTimeout(function()
        {
            $goods_form.find('button[type="submit"]').button('reset');
        }, 3000);
    });

    // 拖拽
    $goods_form.find('.field-content').dragsort({ dragSelector: 'i.drag-submit', placeHolderTemplate: '<li class="drag-sort-dotted am-fl"></li>'});
});