$(function()
{
    // 弹窗批量设置
    $(document).on('click', '.popup-batch-all-submit', function()
    {
        var $parents = $(this).parents('table.am-table');
        var value = $parents.find('thead tr th input').val() || '';
        $parents.find('tbody tr td input[type="number"]').val(value);
        $('#popup-batch-dropdown-'+$(this).data('id')).dropdown('close');
    });
});