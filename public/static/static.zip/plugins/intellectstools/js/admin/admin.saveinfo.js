$(function()
{
    // popup 容器   
    var $popup = $('#intellectstools-goods-popup');

    // 分页
    $('.goods-page-container').html(PageLibrary());

    // 开启商品弹窗
    $('.goods-popup-add').on('click', function()
    {
        // 操作标记
        $popup.attr('data-tag', $(this).data('tag') || '');
        $popup.attr('data-form-name', $(this).data('form-name') || '');

        // 初始化搜索数据
        $('.goods-page-container').html(PageLibrary());
        $popup.find('.search-submit').trigger('click');
        // 打开弹窗
        $popup.modal();
    });

    // 搜索商品
    $(document).on('click', '.forth-selection-container .search-submit, .pagelibrary li a', function()
    {
        // 分页处理
        var is_active = $(this).data('is-active') || 0;
        if(is_active == 1)
        {
            return false;
        }
        var page = $(this).data('page') || 1;

        // 请求参数
        var url = $('.forth-selection-container').data('search-url');
        var category_id = $('.forth-selection-form-category').val();
        var keywords = $('.forth-selection-form-keywords').val();
        var goods_ids = [];
        $($popup.attr('data-tag')).find('input[type="hidden"]').each(function(k, v)
        {
            goods_ids.push($(this).val());
        });

        var $this = $(this);
        if($(this).hasClass('search-submit'))
        {
            $this.button('loading');
        }
        $('.goods-list-container ul.am-gallery').html('<div class="table-no"><i class="am-icon-spinner am-icon-pulse"></i> '+($('.goods-list-container').data('loading-msg'))+'</div>');
        $.ajax({
            url: url,
            type: 'post',
            data: {"page":page, "category_id":category_id, "keywords":keywords, "goods_ids":goods_ids},
            dataType: 'json',
            success:function(res)
            {
                $this.button('reset');
                if(res.code == 0)
                {
                    $('.goods-list-container').attr('data-is-init', 0);
                    $('.goods-list-container ul.am-gallery').html(res.data.data);
                    $('.goods-page-container').html(PageLibrary(res.data.total, res.data.page_size, res.data.page, 4));
                } else {
                    Prompt(res.msg);
                    $('.goods-list-container ul.am-gallery').html('<div class="table-no"><i class="am-icon-warning"></i> '+res.msg+'</div>');
                }
            },
            error:function(res)
            {
                $this.button('reset');
                Prompt('请求失败');
                $('.goods-list-container ul.am-gallery').html('<div class="table-no"><i class="am-icon-warning"></i> 请求失败</div>');
            }
        });
    });

    // 删除列表
    $(document).on('click', '.appoint-goods-container li button.am-close', function()
    {
        $(this).parents('li').remove();
    });

    // 商品添加/删除
    $(document).on('click', '.goods-list-container .goods-add-submit, .goods-list-container .goods-del-submit', function()
    {
        // 基础参数
        var $this = $(this);
        var type = $this.data('type');
        var icon_html = $this.parents('li').data((type == 'add' ? 'del' : 'add')+'-html');
        var goods_id = $this.parents('li').data('gid');
        var goods_title = $this.parents('li').data('title');
        var goods_url = $this.parents('li').data('url');
        var goods_img = $this.parents('li').data('img');
        var tag = $popup.attr('data-tag') || '';
        var form_name = $popup.attr('data-form-name') || '';

        // 商品是否已经添加
        if($(tag).find('.appoint-goods-'+goods_id).length > 0)
        {
            $(tag).find('.appoint-goods-'+goods_id).remove();
        } else {
            $(tag).append('<li class="appoint-goods-'+goods_id+' am-padding-left-xs"><input type="hidden" name="'+form_name+'['+goods_id+'][id]" value="'+goods_id+'" /><input type="text" name="'+form_name+'['+goods_id+'][name]" placeholder="名称" class="am-radius" /> <a href="'+goods_url+'" target="_blank" class="am-text-truncate"><img src="'+goods_img+'" alt="'+goods_title+'" class="am-fl am-margin-right-xs" width="20" height="20" /><span>'+goods_title+'</span></a><button type="button" class="am-close am-fr">&times;</button></li>');
        }
        $this.parent().html(icon_html);
    });

    // 移除
    $('.appoint-ladder-goods-config-container').on('click', '.icon-delete', function()
    {
        $(this).parent().remove();
    });
});