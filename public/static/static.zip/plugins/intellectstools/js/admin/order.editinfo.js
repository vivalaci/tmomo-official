$(function()
{
    /**
     * 金额计算处理
     * @author  Devil
     * @blog    http://gong.gg/
     * @version 1.0.0
     * @date    2021-05-07
     * @desc    description
     * @param   {[ int]}        event_type [事件类型（0选择、1操作金额、2订单金额）]
     */
    function PluginsIntellectstoolsOrderPirce(event_type)
    {
        // 订单金额
        var order_opt_total_price = parseFloat($('.intellectstools-order-price-container').data('order-opt-total-price') || 0);

        // 操作类型
        var opt_type = parseInt($('.intellectstools-order-price-container input[name="opt_type"]:checked').val() || 0);

        // 操作金额
        var opt_price = parseFloat($('.intellectstools-order-price-container input[name="opt_price"]').val() || 0);

        // 订单金额
        var total_price = parseFloat($('.intellectstools-order-price-container input[name="total_price"]').val() || 0);

        // 订单金额事件、根据输入的订单金额自动计算操作金额和操作类型
        if(event_type == 2)
        {
            if(total_price > order_opt_total_price)
            {
                opt_type = 1;
                opt_price = total_price-order_opt_total_price;
                $('.intellectstools-order-price-container input[name="opt_type"]').eq(1).uCheck('check');
            } else {
                opt_type = 0;
                opt_price = order_opt_total_price-total_price;
                $('.intellectstools-order-price-container input[name="opt_type"]').eq(0).uCheck('check');
            }
        }

        // 金额计算
        var price = 0;
        if(opt_type == 0)
        {
            if(opt_price > order_opt_total_price)
            {
                opt_price = order_opt_total_price;
            }
            price = order_opt_total_price-opt_price;
        } else {
            price = order_opt_total_price+opt_price;
        }

        $('.intellectstools-order-price-container input[name="opt_price"]').val(opt_price.toFixed(2));
        $('.intellectstools-order-price-container input[name="total_price"]').val(price.toFixed(2));
    }

    // 操作类型事件
    $('.intellectstools-order-price-container input[name="opt_type"]').on('change', function()
    {
        PluginsIntellectstoolsOrderPirce(0);
    });

    // 操作金额事件
    $('.intellectstools-order-price-container input[name="opt_price"]').on('blur', function()
    {
        var opt_price = parseFloat($(this).val() || 0);
        if(isNaN(opt_price))
        {
            opt_price = 0;
        } else {
            opt_price = parseFloat((Math.round(opt_price*100)/100).toFixed(2));
            if(opt_price < 0)
            {
                opt_price = 0;
            }
        }
        $(this).val(opt_price.toFixed(2));

        PluginsIntellectstoolsOrderPirce(1);
    });

    // 订单金额事件
    $('.intellectstools-order-price-container input[name="total_price"]').on('blur', function()
    {
        var total_price = parseFloat($(this).val()) || 0;
        if(isNaN(total_price))
        {
            total_price = 0;
        } else {
            total_price = parseFloat((Math.round(total_price*100)/100).toFixed(2));
            if(total_price < 0)
            {
                total_price = 0;
            }
        }
        $(this).val(total_price.toFixed(2));

        PluginsIntellectstoolsOrderPirce(2);
    });

    // 价格点击选中
    $('.intellectstools-order-price-container input[name="opt_price"],.intellectstools-order-price-container input[name="total_price"]').on('click', function()
    {
        $(this).select();
    });
});