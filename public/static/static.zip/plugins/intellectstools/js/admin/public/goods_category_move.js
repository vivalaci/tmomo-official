$(function()
{
    // 商品分类批量移动
    $('.submit-category-move').on('click', function()
    {
        // 获取商品id
        var values = FromTableCheckedValues('form_checkbox_value', '.am-table-scrollable-horizontal');
        if(values.length <= 0)
        {
            Prompt(window['lang_before_choice_data_tips'] || '请先选择数据');
            return false;
        }

        // 开启弹窗
        $('#plugins-intellectstools-category-popup').modal();
    });

    // 分类选择切换
    $('#plugins-intellectstools-category-popup').on('click',  '.layout-category-choice .goods-category-choice-content ul li a', function()
    {
        // 父级
        var $parents = $(this).parents('.goods-category-choice');

        // 选中
        $(this).parent().addClass('active').siblings().removeClass('active');

        // 分类数据
        var data = $(this).find('span.data-json').text() || null;
        if(data != null)
        {
            data = JSON.parse(CryptoJS.enc.Base64.parse(decodeURIComponent(data)).toString(CryptoJS.enc.Utf8))
        }

        // 参数
        var level = $(this).parents('ul').data('level') || 1;
        var level_next = level+1;

        // 拼接html
        if(data != null && level < 3)
        {
            var html = '';
            for(var i in data)
            {
                var json = ((data[i]['items'] || null) == null || data[i]['items'].length == 0) ? '' : encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(data[i]['items']))));
                html += '<li><a href="javascript:;" data-value="'+data[i]['id']+'">';
                html += '<span class="data-name">'+data[i]['name']+'</span>';
                html += '<span class="data-json am-hide">'+json+'</span>';
                if((data[i]['items'] || null) != null && data[i]['items'].length > 0)
                {
                    html += '<i class="iconfont icon-angle-right am-fr"></i>';
                }
                html += '</a></li>';
            }
            $parents.find('.goods-category-select-'+level_next).html(html).removeClass('am-hide');
        }

        // 级别数据处理
        if(data == null)
        {
            $parents.find('.goods-category-select-'+level_next).addClass('am-hide').html('');
        } else {
            $parents.find('.goods-category-select-'+level_next).removeClass('am-hide');
        }

        // 选择第一级的时候隐藏第三级
        if(level == 1)
        {
            $parents.find('.goods-category-select-3').addClass('am-hide').html('');
        }

        // 提示信息展示
        var text = '';
        var value = [];
        $parents.find('ul li.active').each(function(k, v)
        {
            if(k > 0)
            {
                text += ' > ';
            }
            var name = $(this).find('a span.data-name').text();
            value.push({"id":$(this).find('a').data('value'), "name":name});
            text += name;
        });
        var $tips = $parents.find('.already-select-tips');
        $tips.find('strong').text(text);

        // 选择数据
        $tips.attr('data-value', encodeURIComponent(JSON.stringify(value)));
    });

    // 移动分类确认
    $('#plugins-intellectstools-category-popup .confirm-move-submit').on('click', function()
    {
        // 父级
        var $parents = $(this).parents('.goods-category-choice');

        // 获取商品id
        var values = FromTableCheckedValues('form_checkbox_value', '.am-table-scrollable-horizontal');
        if(values.length <= 0)
        {
            Prompt(window['lang_before_choice_data_tips'] || '请先选择数据');
            return false;
        }

        // 分类数据
        var json = $parents.find('.already-select-tips').attr('data-value') || null;
        if(json != null)
        {
            json = JSON.parse(decodeURIComponent(json)) || null;
        }
        if(json == null)
        {
            Prompt('请先选择商品分类');
            return false;
        }
        var category = json[json.length-1];

        // 保存分类
        var $this = $(this);
        $this.button('loading');
        $.ajax({
            url: $this.data('url'),
            type: 'post',
            dataType: 'json',
            data: {"goods_ids": values, "category_id": category.id},
            success: function(res)
            {
                if(res.code == 0)
                {
                    Prompt(res.msg, 'success');
                    setTimeout(function()
                    {
                        window.location.reload();
                    }, 2000);
                } else {
                    $this.button('reset');
                    Prompt(res.msg);
                }
            },
            error: function(xhr, type)
            {
                var msg = HtmlToString(xhr.responseText) || '异常错误';
                Prompt(msg, null, 30);
                $this.button('reset');
            }
        });
    });
});