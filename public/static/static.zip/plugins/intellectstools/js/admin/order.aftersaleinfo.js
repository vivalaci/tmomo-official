// 订单售后基础数据处理
function PluginsIntellectstoolsAftersaleBaseHandle()
{
    var count = 0;
    var price = 0;
    $('.goods-list tbody tr').each(function(k ,v)
    {
        price += parseFloat($(this).find('td:eq(1) input').val() || 0);
        count += parseInt($(this).find('td:eq(2) input').val() || 0);
    });
    $('.goods-buttom-total .count').text(count);
    $('.goods-buttom-total .total-price').text(__currency_symbol__+FomatFloat(price));

    return {count: count, price: price};
}

// 订单售后价格处理
function PluginsIntellectstoolsAftersalePriceHandle(e)
{
    var $parent = e.parents('tr');
    var number = parseInt($parent.find('td:eq(2) input').val() || 0);
    var price = parseFloat($parent.find('td:eq(1) input').data('original-price') || 0);
    var value = '';
    if(number > 0)
    {
        value = number*price;
        var total_price = parseFloat($parent.find('td:eq(1) input').data('original-total-price') || 0);
        if(value > total_price)
        {
            value = total_price;
        }
        value = FomatFloat(value);
    }
    $parent.find('td:eq(1) input').val(value);
}

$(function()
{
    // 数量操作
    $(document).on('click', '.number-operate span', function()
    {
        var $input = $(this).parents('.number-operate').find('input');
        var min = parseInt($input.data('min') || 0);
        var max = parseInt($input.data('max') || 0);
        var stock = parseInt($input.val() || 0);
        var type = $(this).data('type');
        var temp_stock = (type == 'add') ? stock+1 : stock-1;
            temp_stock = (temp_stock < min) ? min : ((temp_stock > max) ? max : temp_stock);
        // 赋值数据并触发离开事件
        $input.val(temp_stock || '').blur();
        // 订单售后价格处理
        PluginsIntellectstoolsAftersalePriceHandle($input);
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });

    // 数量输入获得焦点事件
    $(document).on('focus', '.number-operate input', function(){
        $(this).select();
    });
    // 数量输入离开事件
    $(document).on('blur', '.number-operate input', function()
    {
        var min = parseInt($(this).data('min') || 0);
        var max = parseInt($(this).data('max') || 0);
        var stock = parseInt($(this).val()) || 0;
        var temp_stock = (stock < min) ? min : ((stock > max) ? max : stock);
        $(this).val(temp_stock || '');
        // 订单售后价格处理
        PluginsIntellectstoolsAftersalePriceHandle($(this));
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });

    // 价格操作
    $(document).on('click', '.price-operate span', function()
    {
        // 设置价格
        var $input = $(this).parents('.price-operate').find('input');
            $input.val(FomatFloat($input.data('original-total-price')));
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });
    // 价格输入获得焦点事件
    $(document).on('focus', '.price-operate input', function(){
        $(this).select();
    });
    // 价格输入离开事件
    $(document).on('blur', '.price-operate input', function()
    {
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });

    // 全部金额事件
    $(document).on('click', '.price-all-submit', function()
    {
        var type = parseInt($(this).data('type') || 0);
        // 循环处理所有的商品
        $('.goods-list tbody tr').each(function(k ,v)
        {
            var $input = $(this).find('td:eq(1) input');
                $input.val(type == 0 ? '' : FomatFloat($input.data('original-total-price')));
        });
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });

    // 全部数量事件
    $(document).on('click', '.number-all-submit', function()
    {
        var type = parseInt($(this).data('type') || 0);
        // 循环处理所有的商品
        $('.goods-list tbody tr').each(function(k ,v)
        {
            var $input = $(this).find('td:eq(2) input');
                $input.val(type == 0 ? '' : $input.data('max'));
        });
        // 订单售后数据处理
        PluginsIntellectstoolsAftersaleBaseHandle();
    });

    // 表单提交
    $('form button[type="submit"]').on('click', function()
    {
        // 商品
        var total = PluginsIntellectstoolsAftersaleBaseHandle();
        if(total.count == 0 && total.price == 0)
        {
            Prompt('请输入需要退款或退货商品');
            return false;
        }

        // 退款方式
        var refundment = $('input[name="refundment"]').val();
        if(refundment == undefined || refundment == '')
        {
            Prompt('请选择退款方式');
            return false;
        }
    });
});