$(function()
{
    // 点击执行脚本
    $('.contab-submit').on('click', function()
    {
        var url = $(this).data('url');
        AMUI.dialog.confirm({
            title: window['lang_reminder_title'] || '温馨提示',
            content: '确定需要执行该脚本吗？',
            onConfirm: function (options) {
                window.open(url);
            },
            onCancel: function () { }
        });
    });
});