$(function()
{
    // 商品批量上下架
    $(document).on('click', '.submit-goods-shelves a', function()
    {
        // 获取商品id
        var values = FromTableCheckedValues('form_checkbox_value', '.am-table-scrollable-horizontal');
        if(values.length <= 0)
        {
            Prompt(window['lang_before_choice_data_tips'] || '请先选择数据');
            return false;
        }

        // 请求接口
        $.ajax({
            url: RequestUrlHandle($('.submit-goods-shelves').data('url')),
            type: 'post',
            dataType: "json",
            timeout: 10000,
            data: { ids: values.join(','), value: $(this).data('value') },
            success: function (res) {
                if (res.code == 0) {
                    Prompt(res.msg, 'success');
                    // 1.5秒后刷新页面
                    setTimeout(function () {
                        window.location.reload();
                    }, 1500);
                } else {
                    Prompt(res.msg);
                }
            },
            error: function (xhr, type) {
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    });
});