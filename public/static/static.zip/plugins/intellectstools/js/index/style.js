/**
 * 获取购物车数据
 * @author  Devil
 * @blog    http://gong.gg/
 * @version 1.0.0
 * @date    2022-07-08
 * @desc    description
 */
function PluginIntellectstoolsCartData () {
    var $obj = $('.plugins-intellectstools-search-right-cart');
    $.ajax({
        url: $obj.data('cart-ajax-url'),
        type: 'post',
        dataType: "json",
        timeout: 10000,
        data: {},
        success: function (result) {
            if (result.code == 0) {
                $obj.find('.cart-content').html(result.data.html);
                $obj.find('.common-cart-total').text(result.data.count || '');
            } else {
                Prompt(result.msg);
            }
        },
        error: function (xhr, type) {
            Prompt(HtmlToString(xhr.responseText) || '异常错误', null, 30);
        }
    });
}

$(function () {
    // 购物车查询
    var cart_status = true;
    $(document).on('mouseenter', '.plugins-intellectstools-search-right-cart', function () {
        // 当前鼠标是否还在元素上，防止鼠标直接进入子级元素导致重复执行事件
        if (cart_status) {
            cart_status = false;
        } else {
            return false;
        }

        // 获取数据
        PluginIntellectstoolsCartData();
    });
    // 鼠标离开元素标记
    $(document).on('mouseleave', '.plugins-intellectstools-search-right-cart', function () {
        cart_status = true;
    });

    // 订单列表点击加入购物车
    $(document).on('click', '.order-cart-again-submit', function () {
        var json = $(this).data('json') || null;
        if (json == null) {
            Prompt('商品数据有误！');
            return false;
        }

        var $this = $(this);
        $.AMUI.progress.start();
        $.ajax({
            url: RequestUrlHandle(__goods_cart_save_url__),
            type: 'post',
            dataType: "json",
            timeout: 10000,
            data: { goods_data: json },
            success: function (res) {
                $.AMUI.progress.done();
                if (res.code == 0) {
                    // 更新公共购物车数量
                    HomeCartNumberTotalUpdate(res.data.buy_number);

                    // 展示购物车成功提示弹窗
                    HomeUserCartSuccessModal(res.data.buy_number);

                    // 关闭下拉选框
                    $this.parents('.am-dropdown').dropdown('close');
                } else {
                    Prompt(res.msg);
                }
            },
            error: function (xhr, type) {
                $.AMUI.progress.done();
                Prompt(HtmlToString(xhr.responseText) || (window['lang_error_text'] || '异常错误'), null, 30);
            }
        });
    });

    // 订单列表点击再次购买
    $(document).on('click', '.order-buy-again-submit', function () {
        var json = $(this).data('json') || null;
        if (json == null) {
            Prompt('商品数据有误！');
            return false;
        }
        // 对象则转字符串
        if (typeof (json) == 'object') {
            json = JSON.stringify(json);
        }
        var goods_data = encodeURIComponent(CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(json)));

        // 表单html加入页面并执行购买
        var html = `<form action="` + $(this).data('buy-url') + `" method="post" class="plugins-intellectstools-buy-form am-hide">
                        <input type="hidden" name="buy_type" value="goods">
                        <input type="hidden" name="goods_data" value="`+ goods_data + `">
                        <button type="submit"></button>
                    </form>`;
        $('.plugins-intellectstools-buy-form').remove();
        $('body').append(html);
        $('body .plugins-intellectstools-buy-form').find('button[type="submit"]').trigger('click');
    });

    // 支付方式仅可以选择下单时候选择的支付方式
    $(document).on('click', '.user-content .submit-pay', function () {
        // 存在开关标识则处理
        if ($('.plugins-intellectstools-order-pay-only-can-buy-payment').length > 0) {
            var payment_id = parseInt($(this).data('payment-id') || 0);
            if (payment_id != 0) {
                $('#order-pay-popup ul.payment-list li').each(function (k, v) {
                    var temp = parseInt($(this).data('value') || 0);
                    if (temp == payment_id) {
                        $(this).removeClass('am-hide');
                    } else {
                        $(this).addClass('am-hide');
                    }
                });
            }
        }
    });

    /**
     * 商品评价打分
     */
    $(document).on('click', 'ul.rating li', function () {
        $(this).parent().find('li i').removeClass('am-icon-star').addClass('am-icon-star-o');
        var index = $(this).index();
        var rating_arr = ('非常差,差,一般,好,非常好').split(',');
        for (var i = 0; i <= index; i++) {
            $(this).parent().find('li').eq(i).find('i').removeClass('am-icon-star-o').addClass('am-icon-star');
        }
        $(this).parent().find('li.tips-text').text(rating_arr[index]);
        $(this).parents('td').find('input.input-rating').val(index + 1).trigger('blur');
        $(this).parent().removeClass('not-selected');
    });

    // 订单确认页面用户留言快捷选择
    $(document).on('click', '.plugins-intellectstools-user-note-choice-container a', function () {
        var value = $(this).text();
        var user_note = $('textarea.memo-input').val() || '';
        if (user_note != '') {
            // 已存在则不追加
            if (user_note.indexOf(value) != -1) {
                return false;
            }
            // 有数据组则增加分割符号
            user_note += ',';
        }
        user_note += value;
        // 大于限定长度则不增加
        var maxlength = parseInt($('textarea.memo-input').attr('maxlength') || 0);
        if (maxlength == 0 || user_note.length <= maxlength) {
            $('textarea.memo-input').val(user_note);
        }
    });
});