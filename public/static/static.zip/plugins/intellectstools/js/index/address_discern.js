$(function()
{
    // 用户地址编辑添加
    var $parent = $('input[name="address"]').parents('.am-form-group');
    var html = '<div class="am-form-group">';
        html += '<label class="block">地址信息智能识别</label>';
        html += '<div class="am-input-group am-input-group-sm am-margin-top-xs plugins-intellectstools-useraddress-save">';
        html += '<textarea rows="6" class="am-radius am-form-field" placeholder="粘贴整段地址，自动拆分姓名、电话及地址" data-validation-message="请填写详情内容顶部提示信息内容"></textarea>';
        html += '<span class="am-input-group-btn">';
        html += '<button type="button" class="am-btn am-btn-default am-radius">识别</button>';
        html += '</span>';
        html += '</div>';
        html += '</div>';
    $parent.after(html);

    // 识别确认事件
    $(document).on('click', '.plugins-intellectstools-useraddress-save button', function()
    {
        var address = $('.plugins-intellectstools-useraddress-save textarea').val() || null;
        if(address == null)
        {
            Prompt('请输入地址信息');
            return false;
        }

        // ajax请求
        $.ajax({
            url: $('.plugins-intellectstools-useraddress-url').data('url'),
            type: 'POST',
            dataType: "json",
            timeout: 10000,
            data: {"address": address, "is_user": 1},
            success: function(result)
            {
                if(result.code == 0)
                {
                    Prompt(result.msg, 'success');
                    // 数据填充
                    FormDataFill(result.data);

                    // 地址联动添加属性数据
                    $('.region-linkage select[name=province]').attr('data-value', result.data.province);
                    $('.region-linkage select[name=city]').attr('data-value', result.data.city);
                    $('.region-linkage select[name=county]').attr('data-value', result.data.county);
                    var address = result.data.province_name + ((result.data.city_name || null) == null ? '' : '-' + result.data.city_name) + ((result.data.county_name || null) == null ? '' : '-' + result.data.county_name);
                    $('.region-linkage input[name="province_city_county"]').val(address);

                    // 地址初始化
                    RegionLinkageInit();
                } else {
                    Prompt(result.msg);
                }
            },
            error: function()
            {
                Prompt('网络异常错误');
            }
        });
    });
});