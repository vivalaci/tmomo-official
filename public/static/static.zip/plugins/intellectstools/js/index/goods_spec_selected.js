$(function()
{
    // 是否存在指定规格初始化选中、存在则不走当前默认选择第一个的规格
    var spec = decodeURIComponent(GetQueryValue('spec') || '');
    // 商品详情页面默认选中第一个规格、必须是可以可售的商品
    if((spec || null) == null && $('.sku-container').length > 0 && $('.sku-container .sku-items').length > 0 && $('.buy-submit-container').length > 0 && ($('.buy-submit-container button.buy-submit').length > 0 || $('.buy-submit-container button.cart-submit').length > 0) && $('.tb-detail-panel-top-price-content .goods-sale-price').length > 0)
    {
        var $price = $('.tb-detail-panel-base .tb-detail-panel-top-price-content .items.price dd b, .tb-detail-panel-base .tb-detail-panel-top-price-content .goods-sale-price .goods-price');
        // 先清除价格展示信息
        $price.text('...');
        var num = 0;
        var timer = setInterval(function()
        {
            $('.sku-container .sku-items').each(function(k, v)
            {
                // 清除价格展示信息、避免获取价格类型赋值
                $price.text('...');
                // 必须不存在已选择项
                if($(this).find('ul li.selected').length <= 0)
                {
                    var status = false;
                    $(this).find('ul li').each(function(ks, vs)
                    {
                        // 必须是可选和未选
                        if(!status && !$(this).hasClass('sku-items-disabled') && !$(this).hasClass('sku-dont-choose'))
                        {
                            $(this).trigger('click');
                            status = true;
                            num++;
                        }
                    });
                }
            });
            if(num >= $('.sku-container .sku-items').length)
            {
                clearInterval(timer);
            }
        }, 100);
        setTimeout(function()
        {
            clearInterval(timer);
        }, 20000);
    }
});