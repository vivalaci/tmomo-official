$(function()
{
    // 计费方式切换
    $('form.am-form input[name=valuation]').on('click', function()
    {
        var $this = $(this);
        var valuation = parseInt($this.val());
        var old_valuation = $(this).parents('.am-form-group').attr('data-value');
        if(old_valuation != valuation)
        {
            AMUI.dialog.confirm({
                title: '温馨提示',
                content: '切换计价方式后，所设置当前模板的运输信息将被清空，确定继续么？',
                onConfirm: function(e)
                {
                    // 内容
                    var valuation_unit = ['件', 'kg', 'm³'];
                    var unit = valuation_unit[valuation] || null;
                    if(unit == null)
                    {
                        Prompt('配置有误');
                        return false;
                    }

                    // 记录原始值
                    $this.parents('.am-form-group').attr('data-value', valuation);

                    // 更新单位
                    $('.freightfee-rules table.am-table thead .first-unit, .freightfee-rules table.am-table thead .continue-unit').text(unit);

                    // 仅保留一条配置
                    $('.freightfee-rules table.am-table tbody tr').slice(1).remove();
                    // 移除多余的子数据
                    $('.freightfee-rules table.am-table tbody tr .group-input-list .item').slice(1).remove();
                    // 清空值
                    $('.freightfee-rules table.am-table tbody tr input').each(function(k, v)
                    {
                        if($(this).val() != 'default')
                        {
                            $(this).val('');
                        }
                    });
                    // 快递名称默认
                    $('.freightfee-rules table.am-table tbody tr input.first-name, .freightfee-rules table.am-table tbody tr input.continue-name').val($('.freightfee-rules').data('default-first-continue-name'));

                    // 首数setp处理
                    var $first = $('.freightfee-rules table.am-table tbody tr input.first');
                    var $continue = $('.freightfee-rules table.am-table tbody tr input.continue');
                    if(valuation == 0)
                    {
                        $first.attr('step', 1).attr('min', 1);
                        $continue.attr('step', 1).attr('min', 1);
                    } else {
                        $first.attr('step', '0.01').attr('min', '0.01');
                        $continue.attr('step', '0.01').attr('min', '0.01');
                        console.log(valuation)
                    }
                },
                onCancel: function()
                {
                    $('form.am-form .valuation-list input[name=valuation]').uCheck('uncheck');
                    $('form.am-form .valuation-list input[value='+old_valuation+']').uCheck('check');
                }
            });
        }
    });

    // 元素添加
    $(document).on('click', '.rules-submit-add', function()
    {
        // 唯一索引
        var index = parseInt(Math.random()*1000001);

        // 元素html
        var freightfee_name = $('.freightfee-rules').data('default-freightfee-name');
        var html = $('.freightfee-rules table.am-table tbody tr:first').prop('outerHTML');
        if(html.indexOf(freightfee_name) >= 0)
        {
            var regexp = new RegExp(freightfee_name);
            html = html.replace(regexp, '<a href="javascript:;" class="am-text-primary line-edit" data-index="'+index+'">'+$('.freightfee-rules').data('default-add-region-name')+'</a>');
        }
        if(html.indexOf('<!--operation-->') >= 0)
        {
            html = html.replace(/<!--operation-->/ig, '<a href="javascript:;" class="am-text-danger line-remove">'+$('.freightfee-rules').data('default-line-remove-name')+'</a>');
        }
        $('.freightfee-rules table.am-table').append(html);

        // 值赋空
        $('.freightfee-rules table.am-table tbody tr:last').find('input').each(function(k, v)
        {
            $(this).attr('value', '');
        });
        $('.freightfee-rules table.am-table tbody tr:last .region-td').text('').addClass('am-hide');

        // 移除原来的class新增新的class
        $('.freightfee-rules table.am-table tbody tr:last').removeClass().addClass('data-list-'+index);

        // name名称设置
        $('.freightfee-rules table.am-table tbody tr:last .region-name').attr('name', 'data['+index+'][region]');
        $('.freightfee-rules table.am-table tbody tr:last .region-name-show').attr('name', 'data['+index+'][region_show]');
        $('.freightfee-rules table.am-table tbody tr:last .first').attr('name', 'data['+index+'][first]');
        $('.freightfee-rules table.am-table tbody tr:last .continue').attr('name', 'data['+index+'][continue]');
        $('.freightfee-rules table.am-table tbody tr:last .fee-name').attr('name', 'data['+index+'][fee_list][0][fee_name]');
        $('.freightfee-rules table.am-table tbody tr:last .first-price').attr('name', 'data['+index+'][fee_list][0][first_price]');
        $('.freightfee-rules table.am-table tbody tr:last .continue-price').attr('name', 'data['+index+'][fee_list][0][continue_price]');
        $('.freightfee-rules table.am-table tbody tr:last .continue-free-shipping-price-name').attr('name', 'data['+index+'][free_shipping_price]');
        $('.freightfee-rules table.am-table tbody tr:last').attr('data-index', index);

        // 移除多余的子数据
        $('.freightfee-rules table.am-table tbody tr:last .group-input-list .item').slice(1).remove();
    });
    // 行移除
    $(document).on('click', '.freightfee-rules table.am-table .line-remove', function()
    {
        $(this).parents('tr').remove();
    });

    // 首费、续费添加
    $(document).on('click', '.first-continue-submit-add', function()
    {
        // 唯一索引
        var index = parseInt(Math.random()*1000001);

        // 元素html
        var parent_index = $(this).parents('tr').attr('data-index') || 0;
        var $obj = $(this).parents('td').find('.group-input-list');
        var html = $obj.find('.item:last').prop('outerHTML');
            $obj.append(html);
        // 更新name
        $obj.find('.item:last .fee-name').attr('name', 'data['+parent_index+'][fee_list]['+index+'][fee_name]');
        $obj.find('.item:last .first-price').attr('name', 'data['+parent_index+'][fee_list]['+index+'][first_price]');
        $obj.find('.item:last .continue-price').attr('name', 'data['+parent_index+'][fee_list]['+index+'][continue_price]');
    });
    // 首费、续费移除（第一个不能移除）
    $(document).on('click', '.first-continue-submit-remove', function()
    {
        if($(this).parent().index() > 0)
        {
            $(this).parent().remove();
        }
    });

    // 地区编辑
    $(document).on('click', '.freightfee-rules table.am-table .line-edit', function()
    {
        var index = $(this).data('index');
        $('#freightfee-region-popup').modal();
        $('#freightfee-region-popup').attr('data-index', index);

        // 清除选中
        $('#freightfee-region-popup').find('.province-name').removeClass('selected').removeClass('selected-may');
        $('#freightfee-region-popup').find('.city-name').parent('li').removeClass('selected');

        // 地区选中
        var ids = $('.data-list-'+index).find('td.first input').val() || null;
        
        if(ids != null)
        {
            var ids_all = ids.split('-');
            for(var i in ids_all)
            {
                $('.region-node-'+ids_all[i]).parent('li').addClass('selected');
            }

            // 父级选择处理
            $('#freightfee-region-popup .city-list').each(function(k, v)
            {
                var items_count = $(this).find('.city-name').length;
                var selected_count = $(this).find('.selected').length;
                if(selected_count >= items_count)
                {
                    $(this).prev('.province-name').removeClass('selected-may').addClass('selected');
                } else if(selected_count > 0 && selected_count < items_count)
                {
                    $(this).prev('.province-name').removeClass('selected').addClass('selected-may');
                } else {
                    $(this).prev('.province-name').removeClass('selected-may').removeClass('selected');
                }
            });
        }
    });

    // 地区选择事件 - 省
    $('#freightfee-region-popup .province-name').on('click', function()
    {
        if($(this).hasClass('selected-may') || $(this).hasClass('selected'))
        {
            $(this).next('.city-list').find('li').removeClass('selected');
            $(this).removeClass('selected-may').removeClass('selected');
        } else {
            $(this).next('.city-list').find('li').addClass('selected');
            $(this).addClass('selected');
        }
    });

    // 地区选择事件 - 城市
    $('#freightfee-region-popup .city-name').on('click', function()
    {
        if($(this).parent('li').hasClass('selected'))
        {
            $(this).parent('li').removeClass('selected');
        } else {
            $(this).parent('li').addClass('selected');
        }

        // 父级处理
        var items_count = $(this).parents('.city-list').find('.city-name').length;
        var selected_count = $(this).parents('.city-list').find('.selected').length;
        if(selected_count >= items_count)
        {
            $(this).parents('.city-list').prev('.province-name').removeClass('selected-may').addClass('selected');
        } else if(selected_count > 0 && selected_count < items_count)
        {
            $(this).parents('.city-list').prev('.province-name').removeClass('selected').addClass('selected-may');
        } else {
            $(this).parents('.city-list').prev('.province-name').removeClass('selected-may').removeClass('selected');
        }
    });

    // 地区选择确认
    $('#freightfee-region-popup .am-form-popup-submit button.confirm-submit').on('click', function()
    {
        var name_all = [];
        var ids_all = [];
        var show_ids_all = [];
        var city_index = 0;
        var province_index = 0;
        var province_id = 0;
        $('#freightfee-region-popup .city-list li').each(function(k, v)
        {
            if($(this).parent('.city-list').prev('.province-name').hasClass('selected'))
            {
                var temp_province_id = $(this).parent('.city-list').prev('.province-name').data('id');
                console.log(temp_province_id)
                if(province_id != temp_province_id)
                {
                    province_id = temp_province_id;
                    name_all[province_index] = $(this).parent('.city-list').prev('.province-name').text();
                    show_ids_all[province_index] = temp_province_id;
                    province_index++;
                }
            } else {
                if($(this).hasClass('selected'))
                {
                    name_all[province_index] = $(this).find('.city-name').text();
                    show_ids_all[province_index] = $(this).find('.city-name').data('city-id');
                    province_index++;
                }
            }
            if($(this).hasClass('selected'))
            {
                ids_all[city_index] = $(this).find('.city-name').data('city-id');
                city_index++;
            }
        });
        var $content = $('.data-list-'+$('#freightfee-region-popup').attr('data-index')+' .region-td');
        $content.text(name_all.join('、'));
        if(name_all.length > 0)
        {
            $content.removeClass('am-hide');
        } else {
            $content.addClass('am-hide');
        }
        
        $('.data-list-'+$('#freightfee-region-popup').attr('data-index')+' td.first input.region-name').val(ids_all.join('-'));
        $('.data-list-'+$('#freightfee-region-popup').attr('data-index')+' td.first input.region-name-show').val(show_ids_all.join('-'));

        $('#freightfee-region-popup').modal('close');
    });


    // 添加元素到右侧
    function RightElementAdd(value, name)
    {
        if($('.forth-selection-container ul.ul-right').find('.items-li-'+value).length == 0)
        {
            var html = '<li class="am-animation-slide-bottom items-li-'+value+'"><span class="name" data-value="'+value+'">'+name+'</span><i class="iconfont icon-delete am-fr"></i></li>';
            $('.forth-selection-container ul.ul-right').append(html);
        }

        // 右侧数据同步
        RightElementGoods();

        // 左侧是否还有内容
        if($('.forth-selection-container ul.ul-left li').length == 0)
        {
            $('.forth-selection-container ul.ul-left .table-no').removeClass('am-hide');
        } else {
            $('.forth-selection-container ul.ul-left .table-no').addClass('am-hide');
        }
    }

    // 批量-商品id同步
    function RightElementGoods()
    {
        var value_all = [];
        $('.forth-selection-container ul.ul-right li').each(function(k, v)
        {
            value_all[k] = $(this).find('span.name').data('value');
        });
        $('.forth-selection-container input[name="goods_ids"]').val(value_all.join(',')).blur();

        // 右侧是否还有数据
        if($('.forth-selection-container ul.ul-right li').length == 0)
        {
            $('.forth-selection-container ul.ul-right .table-no').removeClass('am-hide');
        } else {
            $('.forth-selection-container ul.ul-right .table-no').addClass('am-hide');
        }
    }
    // 左侧点击到右侧
    $('.forth-selection-container ul.ul-left').on('click', 'i.icon-angle-right', function()
    {
        var value = $(this).prev().data('value');
        var name = $(this).prev().text();
        $(this).parent().remove();
        RightElementAdd(value, name);
    });

    // 左侧全部移动到右侧
    $('.forth-selection-container .selected-all').on('click', function()
    {
        $('.forth-selection-container ul.ul-left li').each(function(k, v)
        {
            var value = $(this).find('span.name').data('value');
            var name = $(this).find('span.name').text();
            $(this).remove();
            RightElementAdd(value, name);
        });
    });

    // 右侧删除
    $('.forth-selection-container ul.ul-right').on('click', 'i.icon-delete', function()
    {
        $(this).parent().remove();
        RightElementGoods();
    });

    // 商品搜索
    $('.forth-selection-form .search-submit').on('click', function()
    {
        var category_id = $('.forth-selection-form .forth-selection-form-category').val();
        var keywords = $('.forth-selection-form .forth-selection-form-keywords').val();

        // ajax请求
        var $btn = $(this);
        $btn.button('loading');
        $.ajax({
            url:$('.forth-selection-form').data('search-url'),
            type:'POST',
            dataType:"json",
            timeout:10000,
            data:{"category_id": category_id, "keywords": keywords},
            success:function(result)
            {
                $btn.button('reset');
                if(result.code == 0)
                {
                    var html = '';
                    for(var i in result.data)
                    {
                        html += '<li class="am-animation-slide-bottom"><span class="name" data-value="'+result['data'][i]['id']+'">'+result['data'][i]['title']+'</span><i class="iconfont icon-angle-right am-fr"></i></li>';
                    }
                    $('ul.ul-left .table-no').addClass('am-hide');
                    $('ul.ul-left li').remove();
                    $('ul.ul-left').append(html);
                } else {
                    Prompt(result.msg);
                }
            },
            error:function()
            {
                $btn.button('reset');
                Prompt('网络异常错误');
            }
        });
    });

    // 特定商品分类运费添加
    $('.goods-category-append-submit').on('change', function()
    {
        var value = $(this).val() || null;
        if(value != null && $('.goods-category-append-list li.data-item-'+value).length == 0)
        {
            var name = $(this).find('option:selected').data('name');
            var html = `<li class="am-nbfc am-padding-xs data-item-`+value+`">
                <input type="hidden" name="goods_category_append[`+value+`][id]" value="`+value+`" />
                <input type="hidden" name="goods_category_append[`+value+`][name]" value="`+name+`" />
                <p class="name am-fl am-text-truncate am-padding-vertical-xs">`+name+`</p>
                <input type="number" name="goods_category_append[`+value+`][price]" step="0.01" min="0" placeholder="额外增加运费" value="" class="am-radius am-fl" />
                <input type="text" name="goods_category_append[`+value+`][icon]" placeholder="显示名称" value="`+name+`" class="am-radius am-fl am-margin-left-xs" />
                <button type="button" class="am-close am-fr">&times;</button>
            </li>`;
            $('.goods-category-append-list').append(html);
        }
    });
    // 特定商品分类运费移除
    $(document).on('click', '.goods-category-append-list li button.am-close', function()
    {
        $(this).parent().remove();
    });

    // 回车搜索
    $('.forth-selection-form .forth-selection-form-keywords').on('keydown', function(event)
    {
        if(event.keyCode == 13)
        {
            $('.forth-selection-form .search-submit').trigger('click');
            return false;
        }
    });
});