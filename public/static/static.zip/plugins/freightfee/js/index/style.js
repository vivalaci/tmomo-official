$(function()
{
    // 运费选择事件
    $('.plugins-freightfee-buy select').on('change', function()
    {
        var warehouse_id = $(this).parents('.plugins-freightfee-buy').data('warehouse-id');
        window.location.href = UrlFieldReplace('freightfee_id_'+warehouse_id, $(this).val(), null, 'buy-items-plugins-freightfee-'+warehouse_id);
    });
});