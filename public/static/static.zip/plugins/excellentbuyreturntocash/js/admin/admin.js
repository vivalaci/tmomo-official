$(function()
{
    // popup
    var $popup = $('#popup-return-coupon-win');

    // 获取返券 json
    function GetReturnCategoryCouponIds()
    {
        var json = $('input[name="return_category_coupon_ids"]').val() || [];
        if(typeof(json) != 'object')
        {
            json = JSON.parse(json);
        }
        return json;
    }

    // 返券渲染
    function ReturnCategoryCouponIdsHtml()
    {
        var json = GetReturnCategoryCouponIds();
        var html = '';
        for(var i in json)
        {
            html += '<li>';
            html += '<span>'+json[i]['category_name']+' / '+json[i]['coupon_name']+((json[i]['order_total_price'] || 0) > 0 ? ' / '+json[i]['order_total_price']+'元' : '')+'</span>';
            html += '<span class="am-badge am-radius am-icon-remove return-coupon-submit-delete"> 移除</span>';
            html += '</li>';
        }
        $('ul.return-category-coupon-list').html(html);
    }

    // 返券添加
    $('.return-coupon-submit-add').on('click', function()
    {
        $popup.modal();
    });

    // 返券移出
    $(document).on('click', '.return-coupon-submit-delete', function()
    {
        // 数据处理
        var index = $(this).parent().index();
        var json = GetReturnCategoryCouponIds();
        json.splice(index, 1);
        $('input[name="return_category_coupon_ids"]').val(JSON.stringify(json));

        // 重新渲染 html
        ReturnCategoryCouponIdsHtml();
    });

    // 选择劵确认
    $popup.find('button').on('click', function()
    {
        // 数据获取处理
        var data = GetFormVal('#popup-return-coupon-win', true);
        if((data.category_id || null) == null)
        {
            Prompt('请选择商品分类');
            return false;
        }
        if((data.coupon_id || null) == null)
        {
            Prompt('请选择优惠券');
            return false;
        }

        // 获取 name
        var fields_arr = ['coupon_id', 'category_id'];
        for(var i in data)
        {
            if(fields_arr.indexOf(i) != -1)
            {
                data[(i.substr(0, i.length-3))+'_name'] = $popup.find('select[name="'+i+'"] option:selected').text();
            }
        }

        // 获取隐藏域 json
        var json = GetReturnCategoryCouponIds();
        json.push(data);
        $('input[name="return_category_coupon_ids"]').val(JSON.stringify(json));

        // 重新渲染 html
        ReturnCategoryCouponIdsHtml();

        // 关闭弹窗
        $popup.modal('close');
    });
});