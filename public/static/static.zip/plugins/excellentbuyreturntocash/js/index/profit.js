$(function()
{
    // 立即结算事件
    $('.settlement-submit').on('click', function()
    {
        $.ajax({
            url:$(this).data('url'),
            type:'POST',
            dataType:"json",
            timeout:$(this).attr('data-timeout') || 30000,
            data:{"id":$(this).data('id')},
            success:function(result)
            {
                if(result.code == 0)
                {
                    Prompt(result.msg, 'success');
                    setTimeout(function()
                    {
                        window.location.reload();
                    }, 1500);
                } else {
                    $modal = $('#modal-plugins-excellentbuyreturntocash-share');
                    $modal.find('.am-modal-hd .msg-text').text(result.msg);
                    $modal.modal({
                        width: 208,
                        height: 100,
                    });
                }
            },
            error:function(xhr, type)
            {
                Prompt(HtmlToString(xhr.responseText) || '异常错误', null, 30);
            }
        });
    });
});