// 表单初始化
FromInit('form.form-validation-username');
FromInit('form.form-validation-sms');
FromInit('form.form-validation-email');